import { describe, it, expect, beforeAll } from 'vitest';
import { encryptData, decryptData, hashSensitiveData } from './encryption';

beforeAll(() => {
  process.env.ENCRYPTION_KEY = 'test-encryption-key-32-chars!!';
  process.env.NODE_ENV = 'development';
});

describe('Encryption Utils', () => {
  describe('encryptData and decryptData', () => {
    it('should encrypt and decrypt data correctly', () => {
      const originalData = 'sensitive information';
      const encrypted = encryptData(originalData);
      const decrypted = decryptData(encrypted);
      
      expect(decrypted).toBe(originalData);
      expect(encrypted).not.toBe(originalData);
    });

    it('should encrypt objects', () => {
      const originalData = { secret: 'password123', user: 'admin' };
      const encrypted = encryptData(JSON.stringify(originalData));
      const decrypted = decryptData(encrypted);
      
      expect(JSON.parse(decrypted)).toEqual(originalData);
    });
  });

  describe('hashSensitiveData', () => {
    it('should hash data consistently', () => {
      const data = 'test data';
      const hash1 = hashSensitiveData(data);
      const hash2 = hashSensitiveData(data);
      
      expect(hash1).toBe(hash2);
    });

    it('should produce different hashes for different data', () => {
      const hash1 = hashSensitiveData('data1');
      const hash2 = hashSensitiveData('data2');
      
      expect(hash1).not.toBe(hash2);
    });
  });
});
