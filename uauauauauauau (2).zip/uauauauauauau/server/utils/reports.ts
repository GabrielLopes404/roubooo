import PDFDocument from 'pdfkit';
import * as XLSX from 'xlsx';
import type { Conta, Fatura, Contato } from '@shared/schema';
import { Readable } from 'stream';

export interface ReportData {
  title: string;
  subtitle?: string;
  date: Date;
  items: any[];
  headers: string[];
  fields: string[];
  totals?: Record<string, number>;
}

export class ReportGenerator {
  static generatePDF(data: ReportData): Readable {
    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    
    doc.fontSize(20).text(data.title, { align: 'center' });
    if (data.subtitle) {
      doc.fontSize(12).text(data.subtitle, { align: 'center' });
    }
    doc.fontSize(10).text(`Gerado em: ${data.date.toLocaleDateString('pt-BR')}`, { align: 'center' });
    doc.moveDown(2);

    const tableTop = doc.y;
    const itemHeight = 30;
    const colWidth = (doc.page.width - 100) / data.headers.length;

    data.headers.forEach((header, i) => {
      doc.fontSize(10).font('Helvetica-Bold')
        .text(header, 50 + (i * colWidth), tableTop, {
          width: colWidth,
          align: 'left'
        });
    });

    doc.moveDown();
    let currentY = doc.y;

    data.items.forEach((item, index) => {
      if (currentY > doc.page.height - 100) {
        doc.addPage();
        currentY = 50;
      }

      data.fields.forEach((field, i) => {
        let value = item[field];
        
        if (value instanceof Date) {
          value = value.toLocaleDateString('pt-BR');
        } else if (typeof value === 'number') {
          value = new Intl.NumberFormat('pt-BR', { 
            style: 'currency', 
            currency: 'BRL' 
          }).format(value);
        } else if (typeof value === 'string' && !isNaN(parseFloat(value))) {
          value = new Intl.NumberFormat('pt-BR', { 
            style: 'currency', 
            currency: 'BRL' 
          }).format(parseFloat(value));
        }

        doc.fontSize(9).font('Helvetica')
          .text(String(value || '-'), 50 + (i * colWidth), currentY, {
            width: colWidth,
            align: 'left'
          });
      });

      currentY += itemHeight;
      doc.y = currentY;
    });

    if (data.totals) {
      doc.moveDown(2);
      doc.fontSize(12).font('Helvetica-Bold');
      Object.entries(data.totals).forEach(([key, value]) => {
        doc.text(`${key}: ${new Intl.NumberFormat('pt-BR', { 
          style: 'currency', 
          currency: 'BRL' 
        }).format(value)}`);
      });
    }

    doc.end();
    return doc;
  }

  static generateExcel(data: ReportData): Buffer {
    const worksheetData: any[][] = [];
    
    worksheetData.push([data.title]);
    if (data.subtitle) {
      worksheetData.push([data.subtitle]);
    }
    worksheetData.push([`Gerado em: ${data.date.toLocaleDateString('pt-BR')}`]);
    worksheetData.push([]);
    
    worksheetData.push(data.headers);
    
    data.items.forEach(item => {
      const row = data.fields.map(field => {
        let value = item[field];
        if (value instanceof Date) {
          return value.toLocaleDateString('pt-BR');
        } else if (typeof value === 'string' && !isNaN(parseFloat(value))) {
          return parseFloat(value);
        }
        return value;
      });
      worksheetData.push(row);
    });

    if (data.totals) {
      worksheetData.push([]);
      Object.entries(data.totals).forEach(([key, value]) => {
        worksheetData.push([key, value]);
      });
    }

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    
    const colWidths = data.headers.map(() => ({ wch: 20 }));
    worksheet['!cols'] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Relatório');
    
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  }

  static async generateContasReport(
    contas: Conta[], 
    format: 'pdf' | 'excel', 
    tipo: 'receber' | 'pagar' | 'todas'
  ): Promise<Readable | Buffer> {
    const filteredContas = tipo === 'todas' ? contas : contas.filter(c => c.tipo === tipo);
    
    const data: ReportData = {
      title: `Relatório de Contas ${tipo === 'receber' ? 'a Receber' : tipo === 'pagar' ? 'a Pagar' : ''}`,
      subtitle: `Total: ${filteredContas.length} contas`,
      date: new Date(),
      headers: ['Descrição', 'Valor', 'Vencimento', 'Status', 'Categoria'],
      fields: ['descricao', 'valor', 'dataVencimento', 'status', 'categoria'],
      items: filteredContas,
      totals: {
        'Total': filteredContas.reduce((sum, c) => sum + parseFloat(c.valor), 0),
      }
    };

    return format === 'pdf' ? this.generatePDF(data) : this.generateExcel(data);
  }

  static async generateFaturasReport(
    faturas: Fatura[], 
    format: 'pdf' | 'excel'
  ): Promise<Readable | Buffer> {
    const data: ReportData = {
      title: 'Relatório de Faturas',
      subtitle: `Total: ${faturas.length} faturas`,
      date: new Date(),
      headers: ['Número', 'Valor', 'Emissão', 'Vencimento', 'Status'],
      fields: ['numero', 'valorTotal', 'dataEmissao', 'dataVencimento', 'status'],
      items: faturas,
      totals: {
        'Total': faturas.reduce((sum, f) => sum + parseFloat(f.valorTotal), 0),
      }
    };

    return format === 'pdf' ? this.generatePDF(data) : this.generateExcel(data);
  }

  static async generateContatosReport(
    contatos: Contato[], 
    format: 'pdf' | 'excel',
    tipo?: 'cliente' | 'fornecedor'
  ): Promise<Readable | Buffer> {
    const filteredContatos = tipo ? contatos.filter(c => c.tipo === tipo) : contatos;
    
    const data: ReportData = {
      title: `Relatório de Contatos ${tipo ? `(${tipo})` : ''}`,
      subtitle: `Total: ${filteredContatos.length} contatos`,
      date: new Date(),
      headers: ['Nome', 'Email', 'Telefone', 'CPF/CNPJ', 'Cidade'],
      fields: ['nome', 'email', 'telefone', 'cpfCnpj', 'cidade'],
      items: filteredContatos,
    };

    return format === 'pdf' ? this.generatePDF(data) : this.generateExcel(data);
  }
}
