import { Router, type Request, type Response } from 'express';
import { uploadAvatar, uploadAnexo, uploadConciliacao } from '../middlewares/upload';
import { requireAuth } from '../middlewares/auth';
import { storage } from '../storage';

const router = Router();

router.post('/avatar', requireAuth, uploadAvatar, async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhum arquivo enviado' });
    }

    const userId = req.session.userId!;
    const avatarPath = `/uploads/avatars/${req.file.filename}`;

    await storage.updateUser(userId, { avatar: avatarPath });

    res.json({ 
      success: true, 
      avatar: avatarPath,
      message: 'Avatar atualizado com sucesso' 
    });
  } catch (error) {
    console.error('Erro ao fazer upload do avatar:', error);
    res.status(500).json({ error: 'Erro ao fazer upload do avatar' });
  }
});

router.post('/anexo', requireAuth, uploadAnexo, async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhum arquivo enviado' });
    }

    const anexoPath = `/uploads/anexos/${req.file.filename}`;

    res.json({ 
      success: true, 
      anexo: anexoPath,
      filename: req.file.originalname,
      message: 'Arquivo enviado com sucesso' 
    });
  } catch (error) {
    console.error('Erro ao fazer upload do anexo:', error);
    res.status(500).json({ error: 'Erro ao fazer upload do anexo' });
  }
});

router.post('/conciliacao', requireAuth, uploadConciliacao, async (req: Request, res: Response) => {
  try {
    const files = req.files as Express.Multer.File[];
    
    if (!files || files.length === 0) {
      return res.status(400).json({ error: 'Nenhum arquivo enviado' });
    }

    const uploadedFiles = files.map(file => ({
      id: file.filename,
      originalName: file.originalname,
      path: `/uploads/conciliacao/${file.filename}`,
      size: file.size,
      mimetype: file.mimetype,
      uploadedAt: new Date().toISOString()
    }));

    res.json({ 
      success: true, 
      files: uploadedFiles,
      count: uploadedFiles.length,
      message: `${uploadedFiles.length} arquivo(s) enviado(s) com sucesso para conciliação` 
    });
  } catch (error) {
    console.error('Erro ao fazer upload de conciliação:', error);
    res.status(500).json({ error: 'Erro ao fazer upload dos arquivos de conciliação' });
  }
});

export default router;
