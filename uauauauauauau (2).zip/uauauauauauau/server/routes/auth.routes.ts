import { Router } from "express";
import * as authController from "../controllers/auth.controller";
import * as passwordResetController from "../controllers/password-reset.controller";
import { requireAuth } from "../middlewares/auth";
import { loginRateLimiter } from "../middlewares/security";

const router = Router();

router.post("/login", loginRateLimiter, authController.login);
router.post("/register", loginRateLimiter, authController.register);
router.post("/logout", authController.logout);
router.get("/me", requireAuth, authController.getMe);
router.put("/profile", requireAuth, authController.updateProfile);

router.post("/forgot-password", loginRateLimiter, passwordResetController.requestPasswordReset);
router.post("/reset-password", loginRateLimiter, passwordResetController.resetPassword);

export default router;
