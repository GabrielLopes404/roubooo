import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download } from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { pageVariants, staggerContainer, fadeInUp, headerVariants, buttonHover } from "@/lib/animations";

const fluxoMensal = [
  { month: "Jan", receitas: 45000, despesas: 32000, saldo: 13000 },
  { month: "Fev", receitas: 52000, despesas: 38000, saldo: 14000 },
  { month: "Mar", receitas: 48000, despesas: 35000, saldo: 13000 },
  { month: "Abr", receitas: 61000, despesas: 42000, saldo: 19000 },
  { month: "Mai", receitas: 55000, despesas: 39000, saldo: 16000 },
  { month: "Jun", receitas: 67000, despesas: 45000, saldo: 22000 },
];

const saldoAcumulado = [
  { month: "Jan", saldo: 13000 },
  { month: "Fev", saldo: 27000 },
  { month: "Mar", saldo: 40000 },
  { month: "Abr", saldo: 59000 },
  { month: "Mai", saldo: 75000 },
  { month: "Jun", saldo: 97000 },
];

const comparativoAnual = [
  { month: "Jan", ano2023: 38000, ano2024: 45000 },
  { month: "Fev", ano2023: 42000, ano2024: 52000 },
  { month: "Mar", ano2023: 39000, ano2024: 48000 },
  { month: "Abr", ano2023: 51000, ano2024: 61000 },
  { month: "Mai", ano2023: 47000, ano2024: 55000 },
  { month: "Jun", ano2023: 53000, ano2024: 67000 },
];

export default function FluxoCaixa() {
  return (
    <motion.div 
      className="flex-1 space-y-4 sm:space-y-6 p-3 sm:p-4 md:p-6 bg-gradient-to-br from-background via-background to-primary/5"
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <motion.div 
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        variants={headerVariants}
      >
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
            Fluxo de Caixa
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">Análise temporal de entradas e saídas</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <Select defaultValue="2024">
            <SelectTrigger className="w-[100px] sm:w-[140px] text-xs sm:text-sm" data-testid="select-year">
              <SelectValue placeholder="Ano" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2022">2022</SelectItem>
            </SelectContent>
          </Select>
          <motion.div variants={buttonHover} whileHover="hover" whileTap="tap" className="flex-1 sm:flex-initial">
            <Button variant="outline" data-testid="button-export" className="w-full sm:w-auto shadow-md hover:shadow-lg transition-shadow">
              <Download className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
              <span className="hidden xs:inline">Exportar</span>
              <span className="xs:hidden">PDF</span>
            </Button>
          </motion.div>
        </div>
      </motion.div>

      <motion.div 
        className="grid gap-3 sm:gap-4 md:gap-6 grid-cols-1 sm:grid-cols-3"
        variants={staggerContainer}
      >
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-success/10 hover:border-success/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Total Receitas (6 meses)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold font-mono text-success">
                R$ 328.000,00
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Média mensal: R$ 54.666,67
              </p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-destructive/10 hover:border-destructive/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Total Despesas (6 meses)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold font-mono text-destructive">
                R$ 231.000,00
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Média mensal: R$ 38.500,00
              </p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Saldo Acumulado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold font-mono text-primary">
                R$ 97.000,00
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Crescimento de 647% no período
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <motion.div variants={fadeInUp}>
        <Card className="border-2 border-primary/20 hover:border-primary/40 transition-all shadow-lg backdrop-blur-sm bg-card/95">
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">Receitas vs Despesas</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300} className="sm:h-[350px]">
            <BarChart data={fluxoMensal}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="month" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '6px'
                }}
              />
              <Legend />
              <Bar dataKey="receitas" fill="hsl(var(--chart-2))" name="Receitas" radius={[4, 4, 0, 0]} />
              <Bar dataKey="despesas" fill="hsl(var(--chart-3))" name="Despesas" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      </motion.div>

      <div className="grid gap-3 sm:gap-4 md:gap-6 md:grid-cols-2">
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl">Evolução do Saldo</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250} className="sm:h-[300px]">
              <LineChart data={saldoAcumulado}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="saldo" 
                  stroke="hsl(var(--chart-1))" 
                  strokeWidth={2}
                  dot={{ fill: 'hsl(var(--chart-1))', r: 4 }}
                  name="Saldo Acumulado"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl">Comparativo Anual</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250} className="sm:h-[300px]">
              <LineChart data={comparativoAnual}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="ano2023" 
                  stroke="hsl(var(--chart-4))" 
                  strokeWidth={2}
                  dot={{ r: 3 }}
                  name="2023"
                />
                <Line 
                  type="monotone" 
                  dataKey="ano2024" 
                  stroke="hsl(var(--chart-1))" 
                  strokeWidth={2}
                  dot={{ r: 3 }}
                  name="2024"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}
