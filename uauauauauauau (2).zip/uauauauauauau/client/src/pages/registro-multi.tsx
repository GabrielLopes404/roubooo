import { useState } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Lock, User, Zap, Eye, EyeOff, ArrowRight, ArrowLeft, Shield, Sparkles, Mail, Building2, Phone, Globe, CheckCircle2, Briefcase, UserCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Checkbox } from "@/components/ui/checkbox";

type AccountType = 'personal' | 'business' | null;

interface FormData {
  accountType: AccountType;
  fullName: string;
  email: string;
  phone: string;
  timezone: string;
  companyName: string;
  cnpj: string;
  segment: string;
  username: string;
  password: string;
  confirmPassword: string;
  acceptTerms: boolean;
}

export default function RegistroMulti() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    accountType: null,
    fullName: "",
    email: "",
    phone: "",
    timezone: "America/Sao_Paulo",
    companyName: "",
    cnpj: "",
    segment: "",
    username: "",
    password: "",
    confirmPassword: "",
    acceptTerms: false,
  });

  const handleChange = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        if (!formData.accountType) {
          toast({
            title: "Selecione o tipo de conta",
            description: "Escolha entre Pessoal ou Empresarial",
            variant: "destructive",
          });
          return false;
        }
        return true;
      case 2:
        if (!formData.fullName || !formData.email || !formData.phone) {
          toast({
            title: "Preencha todos os campos",
            description: "Nome, e-mail e telefone são obrigatórios",
            variant: "destructive",
          });
          return false;
        }
        return true;
      case 3:
        if (formData.accountType === 'business') {
          if (!formData.companyName || !formData.cnpj || !formData.segment) {
            toast({
              title: "Preencha os dados da empresa",
              description: "Todos os campos empresariais são obrigatórios",
              variant: "destructive",
            });
            return false;
          }
        }
        return true;
      case 4:
        if (!formData.username || !formData.password || !formData.confirmPassword) {
          toast({
            title: "Preencha todos os campos",
            description: "Usuário e senha são obrigatórios",
            variant: "destructive",
          });
          return false;
        }
        if (formData.password !== formData.confirmPassword) {
          toast({
            title: "Senhas não coincidem",
            description: "As senhas devem ser iguais",
            variant: "destructive",
          });
          return false;
        }
        if (formData.password.length < 6) {
          toast({
            title: "Senha muito curta",
            description: "A senha deve ter no mínimo 6 caracteres",
            variant: "destructive",
          });
          return false;
        }
        if (!formData.acceptTerms) {
          toast({
            title: "Aceite os termos",
            description: "Você precisa aceitar os termos de serviço e políticas de privacidade",
            variant: "destructive",
          });
          return false;
        }
        return true;
      default:
        return true;
    }
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      if (currentStep === 2 && formData.accountType === 'personal') {
        setCurrentStep(4); // Pula a etapa de empresa
      } else {
        setCurrentStep(prev => prev + 1);
      }
    }
  };

  const prevStep = () => {
    if (currentStep === 4 && formData.accountType === 'personal') {
      setCurrentStep(2); // Volta direto para dados pessoais
    } else {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleRegister = async () => {
    if (!validateStep(4)) return;

    setIsLoading(true);

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: formData.username,
          password: formData.password,
          email: formData.email,
          fullName: formData.fullName,
          company: formData.accountType === 'business' ? formData.companyName : undefined,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setCurrentStep(5); // Vai para tela de confirmação de email
      } else {
        toast({
          title: "Erro ao criar conta",
          description: data.message || "Erro ao criar conta",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao conectar com o servidor",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const floatingShapes = [
    { size: "w-64 h-64", color: "from-violet-500/10 to-purple-500/10", position: "top-10 left-10", delay: 0 },
    { size: "w-96 h-96", color: "from-blue-500/10 to-cyan-500/10", position: "bottom-20 right-20", delay: 0.5 },
    { size: "w-80 h-80", color: "from-pink-500/10 to-rose-500/10", position: "top-1/2 right-1/4", delay: 1 },
  ];

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 300 : -300,
      opacity: 0
    })
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-violet-50 via-white to-purple-50 p-4 md:p-6 lg:p-8 relative overflow-hidden">
      {/* Animated Background Shapes */}
      {floatingShapes.map((shape, index) => (
        <motion.div
          key={index}
          className={`absolute ${shape.size} ${shape.position} bg-gradient-to-br ${shape.color} rounded-full blur-3xl`}
          animate={{
            y: [0, -30, 0],
            x: [0, 20, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 8 + index * 2,
            repeat: Infinity,
            ease: "easeInOut",
            delay: shape.delay,
          }}
        />
      ))}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl relative z-10"
      >
        <Card className="border-2 border-violet-100 bg-white/95 backdrop-blur-xl shadow-2xl">
          <CardHeader className="space-y-6 text-center pb-6">
            {/* Logo */}
            <motion.div
              className="flex justify-center"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
            >
              <Link href="/">
                <div className="relative cursor-pointer">
                  <div className="relative flex items-center justify-center h-20 w-20 rounded-2xl bg-gradient-to-br from-violet-500 via-purple-500 to-pink-500 shadow-lg">
                    <Zap className="h-10 w-10 text-white" strokeWidth={2.5} />
                  </div>
                </div>
              </Link>
            </motion.div>

            {/* Progress Steps */}
            <div className="flex items-center justify-center gap-2 px-4">
              {[1, 2, 3, 4, 5].map((step) => {
                // Esconder step 3 se for conta pessoal
                if (step === 3 && formData.accountType === 'personal') return null;
                
                return (
                  <div key={step} className="flex items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                        currentStep === step
                          ? 'bg-gradient-to-br from-violet-500 to-purple-500 text-white scale-110'
                          : currentStep > step
                          ? 'bg-green-500 text-white'
                          : 'bg-gray-200 text-gray-500'
                      }`}
                    >
                      {currentStep > step ? <CheckCircle2 className="h-4 w-4" /> : step}
                    </div>
                    {step < (formData.accountType === 'personal' ? 4 : 5) && (
                      <div className={`w-8 h-1 ${currentStep > step ? 'bg-green-500' : 'bg-gray-200'}`} />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Title */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <CardTitle className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-violet-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                {currentStep === 1 && "Escolha o tipo de conta"}
                {currentStep === 2 && "Seus dados"}
                {currentStep === 3 && "Dados da empresa"}
                {currentStep === 4 && "Crie sua senha"}
                {currentStep === 5 && "Confirme seu e-mail"}
              </CardTitle>
              <CardDescription className="mt-2 text-gray-600">
                {currentStep === 1 && "Selecione o tipo de conta que melhor se adequa a você"}
                {currentStep === 2 && "Preencha suas informações pessoais"}
                {currentStep === 3 && "Informações da sua empresa"}
                {currentStep === 4 && "Defina uma senha segura para sua conta"}
                {currentStep === 5 && "Verifique sua caixa de entrada"}
              </CardDescription>
            </motion.div>
          </CardHeader>

          <CardContent className="pb-8">
            <AnimatePresence mode="wait" custom={currentStep}>
              <motion.div
                key={currentStep}
                custom={currentStep}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.3 }}
              >
                {/* Step 1: Account Type */}
                {currentStep === 1 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <button
                      onClick={() => handleChange('accountType', 'personal')}
                      className={`p-6 rounded-xl border-2 transition-all ${
                        formData.accountType === 'personal'
                          ? 'border-violet-500 bg-violet-50'
                          : 'border-gray-200 hover:border-violet-300'
                      }`}
                    >
                      <UserCircle2 className={`h-12 w-12 mx-auto mb-3 ${formData.accountType === 'personal' ? 'text-violet-600' : 'text-gray-400'}`} />
                      <h3 className="font-semibold text-lg mb-1">Pessoal</h3>
                      <p className="text-sm text-gray-600">Para uso individual</p>
                    </button>
                    <button
                      onClick={() => handleChange('accountType', 'business')}
                      className={`p-6 rounded-xl border-2 transition-all ${
                        formData.accountType === 'business'
                          ? 'border-violet-500 bg-violet-50'
                          : 'border-gray-200 hover:border-violet-300'
                      }`}
                    >
                      <Briefcase className={`h-12 w-12 mx-auto mb-3 ${formData.accountType === 'business' ? 'text-violet-600' : 'text-gray-400'}`} />
                      <h3 className="font-semibold text-lg mb-1">Empresarial</h3>
                      <p className="text-sm text-gray-600">Para empresas e equipes</p>
                    </button>
                  </div>
                )}

                {/* Step 2: Personal Data */}
                {currentStep === 2 && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="fullName">Nome Completo</Label>
                      <div className="relative mt-2">
                        <User className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <Input
                          id="fullName"
                          type="text"
                          placeholder="Seu nome completo"
                          value={formData.fullName}
                          onChange={(e) => handleChange("fullName", e.target.value)}
                          className="pl-11 h-12"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="email">E-mail</Label>
                      <div className="relative mt-2">
                        <Mail className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="seu@email.com"
                          value={formData.email}
                          onChange={(e) => handleChange("email", e.target.value)}
                          className="pl-11 h-12"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="phone">Telefone</Label>
                      <div className="relative mt-2">
                        <Phone className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="(00) 00000-0000"
                          value={formData.phone}
                          onChange={(e) => handleChange("phone", e.target.value)}
                          className="pl-11 h-12"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="timezone">Fuso Horário</Label>
                      <div className="relative mt-2">
                        <Globe className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <select
                          id="timezone"
                          value={formData.timezone}
                          onChange={(e) => handleChange("timezone", e.target.value)}
                          className="w-full h-12 pl-11 pr-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                        >
                          <option value="America/Sao_Paulo">São Paulo (BRT)</option>
                          <option value="America/Manaus">Manaus (AMT)</option>
                          <option value="America/Fortaleza">Fortaleza (BRT)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 3: Company Data */}
                {currentStep === 3 && formData.accountType === 'business' && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="companyName">Nome da Empresa</Label>
                      <div className="relative mt-2">
                        <Building2 className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <Input
                          id="companyName"
                          type="text"
                          placeholder="Nome da sua empresa"
                          value={formData.companyName}
                          onChange={(e) => handleChange("companyName", e.target.value)}
                          className="pl-11 h-12"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="cnpj">CNPJ</Label>
                      <div className="relative mt-2">
                        <Building2 className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <Input
                          id="cnpj"
                          type="text"
                          placeholder="00.000.000/0000-00"
                          value={formData.cnpj}
                          onChange={(e) => handleChange("cnpj", e.target.value)}
                          className="pl-11 h-12"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="segment">Segmento</Label>
                      <div className="relative mt-2">
                        <Briefcase className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <select
                          id="segment"
                          value={formData.segment}
                          onChange={(e) => handleChange("segment", e.target.value)}
                          className="w-full h-12 pl-11 pr-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                          required
                        >
                          <option value="">Selecione um segmento</option>
                          <option value="tecnologia">Tecnologia</option>
                          <option value="comercio">Comércio</option>
                          <option value="servicos">Serviços</option>
                          <option value="industria">Indústria</option>
                          <option value="outro">Outro</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 4: Password */}
                {currentStep === 4 && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="username">Nome de Usuário</Label>
                      <div className="relative mt-2">
                        <User className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <Input
                          id="username"
                          type="text"
                          placeholder="seunome"
                          value={formData.username}
                          onChange={(e) => handleChange("username", e.target.value)}
                          className="pl-11 h-12"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="password">Senha</Label>
                      <div className="relative mt-2">
                        <Lock className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Mínimo 6 caracteres"
                          value={formData.password}
                          onChange={(e) => handleChange("password", e.target.value)}
                          className="pl-11 pr-11 h-12"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3.5 top-3.5 text-gray-400 hover:text-gray-600"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                      <div className="relative mt-2">
                        <Lock className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-400" />
                        <Input
                          id="confirmPassword"
                          type={showConfirmPassword ? "text" : "password"}
                          placeholder="Repita a senha"
                          value={formData.confirmPassword}
                          onChange={(e) => handleChange("confirmPassword", e.target.value)}
                          className="pl-11 pr-11 h-12"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3.5 top-3.5 text-gray-400 hover:text-gray-600"
                        >
                          {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 mt-4 p-4 bg-violet-50 rounded-lg">
                      <Checkbox
                        id="terms"
                        checked={formData.acceptTerms}
                        onCheckedChange={(checked) => handleChange("acceptTerms", checked)}
                      />
                      <label htmlFor="terms" className="text-sm text-gray-700 cursor-pointer">
                        Aceito os{" "}
                        <a href="/termos" className="text-violet-600 hover:underline font-medium">
                          termos de serviço
                        </a>{" "}
                        e{" "}
                        <a href="/privacidade" className="text-violet-600 hover:underline font-medium">
                          políticas de privacidade
                        </a>
                      </label>
                    </div>
                  </div>
                )}

                {/* Step 5: Email Confirmation */}
                {currentStep === 5 && (
                  <div className="text-center py-8">
                    <div className="inline-flex p-6 bg-green-100 rounded-full mb-6">
                      <CheckCircle2 className="h-16 w-16 text-green-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">Conta criada com sucesso!</h3>
                    <p className="text-gray-600 mb-6">
                      Enviamos um e-mail de confirmação para <strong>{formData.email}</strong>
                    </p>
                    <p className="text-sm text-gray-500 mb-4">
                      Não recebeu instruções de confirmação?
                    </p>
                    <Button
                      variant="outline"
                      onClick={() => {
                        toast({
                          title: "E-mail reenviado!",
                          description: "Verifique sua caixa de entrada",
                        });
                      }}
                      className="mb-6"
                    >
                      Reenviar e-mail
                    </Button>
                    <div className="pt-6 border-t">
                      <Button
                        onClick={() => setLocation("/dashboard")}
                        className="w-full bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500 hover:from-violet-600 hover:via-purple-600 hover:to-pink-600"
                      >
                        Ir para o Dashboard
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                )}

                {/* Navigation Buttons */}
                {currentStep < 5 && (
                  <div className="flex gap-3 mt-6">
                    {currentStep > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        onClick={prevStep}
                        className="flex-1"
                      >
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Voltar
                      </Button>
                    )}
                    <Button
                      type="button"
                      onClick={currentStep === 4 ? handleRegister : nextStep}
                      disabled={isLoading}
                      className="flex-1 bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500 hover:from-violet-600 hover:via-purple-600 hover:to-pink-600"
                    >
                      {isLoading ? (
                        "Criando conta..."
                      ) : currentStep === 4 ? (
                        <>
                          Criar Conta
                          <CheckCircle2 className="h-4 w-4 ml-2" />
                        </>
                      ) : (
                        <>
                          Próximo
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {/* Login Link */}
                {currentStep < 5 && (
                  <div className="text-center mt-6">
                    <p className="text-sm text-gray-600">
                      Já tem uma conta?{" "}
                      <Link href="/login">
                        <span className="font-semibold text-violet-600 hover:text-violet-700 cursor-pointer">
                          Fazer login
                        </span>
                      </Link>
                    </p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
