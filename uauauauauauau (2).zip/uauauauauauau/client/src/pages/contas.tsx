import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/empty-state";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Plus, 
  Search, 
  MoreHorizontal,
  Edit,
  Trash,
  CheckCircle2,
  Filter,
  Receipt,
  TrendingUp,
  TrendingDown
} from "lucide-react";
import { StatusBadge } from "@/components/status-badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 }
};

export default function Contas() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterTipo, setFilterTipo] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data: contas = [] } = useQuery({
    queryKey: ["/api/contas"],
  });

  const { data: contatos = [] } = useQuery({
    queryKey: ["/api/contatos"],
  });

  const createContaMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/contas", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contas"] });
      setIsCreateDialogOpen(false);
      toast({ title: "Conta criada com sucesso!" });
    },
  });

  const updateContaMutation = useMutation({
    mutationFn: ({ id, ...data }: any) => apiRequest("PUT", `/api/contas/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contas"] });
      toast({ title: "Conta atualizada com sucesso!" });
    },
  });

  const deleteContaMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/contas/${id}`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contas"] });
      toast({ title: "Conta excluída com sucesso!" });
    },
  });

  const handleCreateConta = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createContaMutation.mutate({
      tipo: formData.get("tipo"),
      descricao: formData.get("descricao"),
      valor: parseFloat(formData.get("valor") as string),
      dataVencimento: new Date(formData.get("dataVencimento") as string),
      categoria: formData.get("categoria"),
      contatoId: formData.get("contatoId") || null,
      observacoes: formData.get("observacoes") || null,
      recorrente: formData.get("recorrente") === "true",
      periodicidade: formData.get("periodicidade") || null,
    });
    e.currentTarget.reset();
  };

  const handleMarkAsPaid = (id: string) => {
    updateContaMutation.mutate({
      id,
      status: "pago",
      dataPagamento: new Date(),
    });
  };

  const handleDelete = (id: string) => {
    if (confirm("Deseja realmente excluir esta conta?")) {
      deleteContaMutation.mutate(id);
    }
  };

  const filteredContas = contas.filter((conta: any) => {
    const matchesSearch = conta.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || conta.status === filterStatus;
    const matchesTipo = filterTipo === "all" || conta.tipo === filterTipo;
    return matchesSearch && matchesStatus && matchesTipo;
  });

  const totals = {
    recebido: contas.filter((c: any) => c.tipo === 'receber' && c.status === 'pago').reduce((sum: number, c: any) => sum + parseFloat(c.valor), 0),
    aReceber: contas.filter((c: any) => c.tipo === 'receber' && c.status !== 'pago').reduce((sum: number, c: any) => sum + parseFloat(c.valor), 0),
    pago: contas.filter((c: any) => c.tipo === 'pagar' && c.status === 'pago').reduce((sum: number, c: any) => sum + parseFloat(c.valor), 0),
    aPagar: contas.filter((c: any) => c.tipo === 'pagar' && c.status !== 'pago').reduce((sum: number, c: any) => sum + parseFloat(c.valor), 0),
  };

  return (
    <div className="flex-1 space-y-6 p-6">
      <motion.div 
        className="flex items-center justify-between"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Transações
          </h1>
          <p className="text-muted-foreground">Gerencie contas a pagar e receber</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button data-testid="button-new-transaction" className="bg-gradient-to-r from-primary to-chart-2">
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Transação
                </Button>
              </motion.div>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Nova Conta</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateConta} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="tipo">Tipo</Label>
                    <select id="tipo" name="tipo" required className="w-full rounded-md border border-input bg-background px-3 py-2">
                      <option value="receber">A Receber</option>
                      <option value="pagar">A Pagar</option>
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="categoria">Categoria</Label>
                    <Input id="categoria" name="categoria" required />
                  </div>
                </div>
                <div>
                  <Label htmlFor="descricao">Descrição</Label>
                  <Textarea id="descricao" name="descricao" required rows={3} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="valor">Valor (R$)</Label>
                    <Input id="valor" name="valor" type="number" step="0.01" required />
                  </div>
                  <div>
                    <Label htmlFor="dataVencimento">Data de Vencimento</Label>
                    <Input id="dataVencimento" name="dataVencimento" type="date" required />
                  </div>
                </div>
                <div>
                  <Label htmlFor="contatoId">Contato (Opcional)</Label>
                  <select id="contatoId" name="contatoId" className="w-full rounded-md border border-input bg-background px-3 py-2">
                    <option value="">Selecione um contato</option>
                    {contatos.map((contato: any) => (
                      <option key={contato.id} value={contato.id}>{contato.nome}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea id="observacoes" name="observacoes" rows={2} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="recorrente">Recorrente</Label>
                    <select id="recorrente" name="recorrente" className="w-full rounded-md border border-input bg-background px-3 py-2">
                      <option value="false">Não</option>
                      <option value="true">Sim</option>
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="periodicidade">Periodicidade</Label>
                    <select id="periodicidade" name="periodicidade" className="w-full rounded-md border border-input bg-background px-3 py-2">
                      <option value="">Selecione</option>
                      <option value="mensal">Mensal</option>
                      <option value="bimestral">Bimestral</option>
                      <option value="trimestral">Trimestral</option>
                      <option value="semestral">Semestral</option>
                      <option value="anual">Anual</option>
                    </select>
                  </div>
                </div>
                <Button type="submit" className="w-full">Criar Conta</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </motion.div>

      <motion.div {...fadeInUp}>
        <Card className="relative overflow-hidden border-2 hover:border-primary/30 transition-colors">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-chart-2/5 opacity-50" />
          <CardHeader className="pb-3 relative z-10">
            <CardTitle className="text-base flex items-center gap-2">
              <Receipt className="h-5 w-5 text-primary" />
              Resumo Financeiro
            </CardTitle>
          </CardHeader>
          <CardContent className="relative z-10">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-success/5 transition-colors">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-success" />
                    <span className="text-sm font-medium text-muted-foreground">Recebido</span>
                  </div>
                  <span className="font-bold font-mono text-lg text-success">
                    R$ {totals.recebido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-warning/5 transition-colors">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-warning" />
                    <span className="text-sm font-medium text-muted-foreground">A Receber</span>
                  </div>
                  <span className="font-bold font-mono text-lg text-warning">
                    R$ {totals.aReceber.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-destructive/5 transition-colors">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="h-4 w-4 text-destructive" />
                    <span className="text-sm font-medium text-muted-foreground">Pago</span>
                  </div>
                  <span className="font-bold font-mono text-lg text-destructive">
                    R$ {totals.pago.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-orange-500/5 transition-colors">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="h-4 w-4 text-orange-500" />
                    <span className="text-sm font-medium text-muted-foreground">A Pagar</span>
                  </div>
                  <span className="font-bold font-mono text-lg text-orange-500">
                    R$ {totals.aPagar.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="border-2 hover:border-primary/30 transition-colors">
          <CardHeader>
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex gap-2">
                <select 
                  value={filterTipo} 
                  onChange={(e) => setFilterTipo(e.target.value)}
                  className="rounded-md border border-input bg-background px-3 py-2"
                >
                  <option value="all">Todos os Tipos</option>
                  <option value="receber">A Receber</option>
                  <option value="pagar">A Pagar</option>
                </select>
                <select 
                  value={filterStatus} 
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="rounded-md border border-input bg-background px-3 py-2"
                >
                  <option value="all">Todos os Status</option>
                  <option value="pendente">Pendente</option>
                  <option value="pago">Pago</option>
                  <option value="vencido">Vencido</option>
                </select>
              </div>
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Pesquisar transações..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-transactions"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredContas.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7}>
                      <EmptyState
                        icon={Plus}
                        title="Nenhuma transação encontrada"
                        description="Comece adicionando sua primeira transação para começar a gerenciar suas finanças"
                        action={{
                          label: "Nova Transação",
                          onClick: () => setIsCreateDialogOpen(true)
                        }}
                        gradient="from-primary to-chart-2"
                      />
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredContas.map((conta: any, index: number) => (
                    <motion.tr 
                      key={conta.id} 
                      data-testid={`transaction-row-${conta.id}`}
                      className="hover:bg-muted/50 transition-colors"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      whileHover={{ scale: 1.01 }}
                    >
                      <TableCell className="font-mono text-sm">
                        {new Date(conta.dataVencimento).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell className="font-medium">{conta.descricao}</TableCell>
                      <TableCell>
                        <Badge variant={conta.tipo === 'receber' ? 'default' : 'secondary'}>
                          {conta.tipo === 'receber' ? 'A Receber' : 'A Pagar'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-medium">{conta.categoria}</Badge>
                      </TableCell>
                      <TableCell className={`text-right font-mono font-bold text-lg ${
                        conta.tipo === 'receber' ? 'text-success' : 'text-destructive'
                      }`}>
                        {conta.tipo === 'receber' ? '+' : '-'}R$ {parseFloat(conta.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={conta.status} />
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" data-testid={`button-actions-${conta.id}`}>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {conta.status !== 'pago' && (
                              <DropdownMenuItem onClick={() => handleMarkAsPaid(conta.id)} data-testid={`button-mark-paid-${conta.id}`}>
                                <CheckCircle2 className="h-4 w-4 mr-2" />
                                Marcar como Pago
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => handleDelete(conta.id)} className="text-destructive" data-testid={`button-delete-${conta.id}`}>
                              <Trash className="h-4 w-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </motion.tr>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
