import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Plus, 
  Search, 
  FileText,
  Download,
  Send,
  Eye,
  MoreHorizontal,
  Edit,
  Trash
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { StatusBadge } from "@/components/status-badge";
import { pageVariants, staggerContainer, fadeInUp, headerVariants, buttonHover } from "@/lib/animations";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Faturas() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data: faturas = [] } = useQuery({
    queryKey: ["/api/faturas"],
  });

  const { data: contatos = [] } = useQuery({
    queryKey: ["/api/contatos"],
  });

  const createFaturaMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/faturas", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/faturas"] });
      setIsCreateDialogOpen(false);
      toast({ title: "Fatura criada com sucesso!" });
    },
  });

  const deleteFaturaMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/faturas/${id}`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/faturas"] });
      toast({ title: "Fatura excluída com sucesso!" });
    },
  });

  const handleCreateFatura = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const valor = parseFloat(formData.get("valor") as string);
    const desconto = parseFloat(formData.get("desconto") as string) || 0;
    
    createFaturaMutation.mutate({
      numero: formData.get("numero"),
      contatoId: formData.get("contatoId"),
      dataEmissao: new Date(formData.get("dataEmissao") as string),
      dataVencimento: new Date(formData.get("dataVencimento") as string),
      valor: valor,
      desconto: desconto,
      valorTotal: valor - desconto,
      observacoes: formData.get("observacoes") || null,
      itens: formData.get("itens") || null,
    });
    e.currentTarget.reset();
  };

  const handleDelete = (id: string) => {
    if (confirm("Deseja realmente excluir esta fatura?")) {
      deleteFaturaMutation.mutate(id);
    }
  };

  const filteredFaturas = faturas.filter((fatura: any) =>
    fatura.numero.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    totalEmAberto: faturas.filter((f: any) => f.status !== 'pago').reduce((sum: number, f: any) => sum + parseFloat(f.valorTotal), 0),
    totalRecebido: faturas.filter((f: any) => f.status === 'pago').reduce((sum: number, f: any) => sum + parseFloat(f.valorTotal), 0),
    pendentes: faturas.filter((f: any) => f.status === 'emitida').length,
    total: faturas.length,
  };

  return (
    <motion.div 
      className="flex-1 space-y-4 sm:space-y-6 p-3 sm:p-4 md:p-6 bg-gradient-to-br from-background via-background to-primary/5"
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <motion.div 
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        variants={headerVariants}
      >
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
            Faturas
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">Emita e gerencie faturas de cobrança</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <motion.div variants={buttonHover} whileHover="hover" whileTap="tap">
              <Button data-testid="button-new-invoice" className="w-full sm:w-auto shadow-lg hover:shadow-xl transition-shadow">
                <Plus className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                <span className="hidden xs:inline">Nova Fatura</span>
                <span className="xs:hidden">Nova</span>
              </Button>
            </motion.div>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Nova Fatura</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateFatura} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="numero">Número da Fatura *</Label>
                  <Input id="numero" name="numero" required placeholder="FAT-2025-001" />
                </div>
                <div>
                  <Label htmlFor="contatoId">Cliente *</Label>
                  <select id="contatoId" name="contatoId" required className="w-full rounded-md border border-input bg-background px-3 py-2">
                    <option value="">Selecione um cliente</option>
                    {contatos.filter((c: any) => c.tipo === 'cliente').map((contato: any) => (
                      <option key={contato.id} value={contato.id}>{contato.nome}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dataEmissao">Data de Emissão *</Label>
                  <Input id="dataEmissao" name="dataEmissao" type="date" required />
                </div>
                <div>
                  <Label htmlFor="dataVencimento">Data de Vencimento *</Label>
                  <Input id="dataVencimento" name="dataVencimento" type="date" required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="valor">Valor (R$) *</Label>
                  <Input id="valor" name="valor" type="number" step="0.01" required />
                </div>
                <div>
                  <Label htmlFor="desconto">Desconto (R$)</Label>
                  <Input id="desconto" name="desconto" type="number" step="0.01" defaultValue="0" />
                </div>
              </div>
              <div>
                <Label htmlFor="itens">Itens da Fatura (JSON)</Label>
                <Textarea id="itens" name="itens" rows={3} placeholder='[{"descricao": "Item 1", "quantidade": 1, "valor": 100}]' />
              </div>
              <div>
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea id="observacoes" name="observacoes" rows={2} />
              </div>
              <Button type="submit" className="w-full">Criar Fatura</Button>
            </form>
          </DialogContent>
        </Dialog>
      </motion.div>

      <motion.div 
        className="grid gap-3 sm:gap-4 md:gap-6 grid-cols-2 md:grid-cols-4"
        variants={staggerContainer}
      >
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Total em Aberto
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold font-mono">R$ {stats.totalEmAberto.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-success/10 hover:border-success/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Total Recebido
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold font-mono text-success">R$ {stats.totalRecebido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-warning/10 hover:border-warning/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Faturas Pendentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">{stats.pendentes}</div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-chart-4/10 hover:border-chart-4/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Total de Faturas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">{stats.total}</div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <motion.div variants={fadeInUp}>
        <Card className="border-2 border-primary/20 hover:border-primary/40 transition-all shadow-lg backdrop-blur-sm bg-card/95">
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Todas as Faturas</CardTitle>
            <div className="relative w-full sm:w-[250px] md:w-[300px]">
              <Search className="absolute left-3 top-1/2 h-3 w-3 sm:h-4 sm:w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 sm:pl-9 text-xs sm:text-sm"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Número</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Emissão</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredFaturas.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                      Nenhuma fatura encontrada
                      <div className="mt-2">
                        <Button variant="link" onClick={() => setIsCreateDialogOpen(true)}>
                          Criar primeira fatura
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredFaturas.map((fatura: any, index: number) => {
                    const contato = contatos.find((c: any) => c.id === fatura.contatoId);
                    return (
                      <motion.tr 
                        key={fatura.id}
                        className="hover:bg-muted/50 transition-colors"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <TableCell className="font-mono text-sm">{fatura.numero}</TableCell>
                        <TableCell>{contato?.nome || 'N/A'}</TableCell>
                        <TableCell className="text-sm">{new Date(fatura.dataEmissao).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell className="text-sm">{new Date(fatura.dataVencimento).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell className="text-right font-mono font-bold">
                          R$ {parseFloat(fatura.valorTotal).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={fatura.status} />
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                Visualizar
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Download className="h-4 w-4 mr-2" />
                                Download PDF
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Send className="h-4 w-4 mr-2" />
                                Enviar por E-mail
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(fatura.id)}>
                                <Trash className="h-4 w-4 mr-2" />
                                Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </motion.tr>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      </motion.div>
    </motion.div>
  );
}
