import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  User, 
  Shield, 
  Bell, 
  Palette, 
  Globe,
  Camera,
  Mail,
  Phone,
  Building,
  MapPin,
  Save,
  Lock,
  Eye,
  EyeOff,
  Loader2,
  Check
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Configuracoes() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  // Form states
  const [profileData, setProfileData] = useState({
    fullName: "",
    username: "",
    email: "",
    phone: "",
    company: "",
    cnpj: "",
    position: "",
    department: "",
    address: "",
    addressNumber: "",
    complement: "",
    neighborhood: "",
    zipCode: "",
    city: "",
    state: "",
    bio: ""
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });

  const [preferences, setPreferences] = useState({
    theme: "system",
    accentColor: "violet",
    language: "pt-br",
    timezone: "America/Sao_Paulo",
    compactMode: false,
    animations: true,
    fontSize: "medium",
    emailFinancialReports: true,
    emailBillsDue: true,
    emailUpdates: false,
    pushTransactions: true,
    pushSecurity: true,
    twoFactorEnabled: false,
    smsSecurityEnabled: false
  });

  // Load current user data
  const { data: currentUser, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
  });

  // Load user data into form when it's available
  useEffect(() => {
    if (currentUser?.user) {
      const user = currentUser.user;
      setProfileData({
        fullName: user.fullName || "",
        username: user.username || "",
        email: user.email || "",
        phone: user.phone || "",
        company: user.company || "",
        cnpj: user.cnpj || "",
        position: user.position || "",
        department: user.department || "",
        address: user.address || "",
        addressNumber: user.addressNumber || "",
        complement: user.complement || "",
        neighborhood: user.neighborhood || "",
        zipCode: user.zipCode || "",
        city: user.city || "",
        state: user.state || "",
        bio: user.bio || ""
      });

      // Load preferences from user.preferences if available
      if (user.preferences) {
        try {
          const savedPrefs = JSON.parse(user.preferences);
          setPreferences(prev => ({ ...prev, ...savedPrefs }));
        } catch (e) {
          console.error("Error parsing user preferences:", e);
        }
      }
    }
  }, [currentUser]);

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", "/api/auth/profile", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ 
        title: "✅ Perfil atualizado!", 
        description: "Suas informações foram salvas com sucesso." 
      });
    },
    onError: () => {
      toast({ 
        title: "❌ Erro", 
        description: "Não foi possível atualizar o perfil.", 
        variant: "destructive" 
      });
    }
  });

  // Change password mutation
  const changePasswordMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", "/api/auth/profile", { password: data.newPassword }),
    onSuccess: () => {
      setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
      toast({ 
        title: "✅ Senha alterada!", 
        description: "Sua senha foi atualizada com sucesso." 
      });
    },
    onError: () => {
      toast({ 
        title: "❌ Erro", 
        description: "Não foi possível alterar a senha.", 
        variant: "destructive" 
      });
    }
  });

  // Save preferences mutation
  const savePreferencesMutation = useMutation({
    mutationFn: (prefs: any) => apiRequest("PUT", "/api/auth/profile", { 
      preferences: JSON.stringify(prefs) 
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ 
        title: "✅ Preferências salvas!", 
        description: "Suas configurações foram atualizadas." 
      });
    },
    onError: () => {
      toast({ 
        title: "❌ Erro", 
        description: "Não foi possível salvar as preferências.", 
        variant: "destructive" 
      });
    }
  });

  const handleSaveProfile = () => {
    updateProfileMutation.mutate(profileData);
  };

  const handleChangePassword = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({ 
        title: "❌ Erro", 
        description: "As senhas não conferem.", 
        variant: "destructive" 
      });
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast({ 
        title: "❌ Erro", 
        description: "A senha deve ter no mínimo 6 caracteres.", 
        variant: "destructive" 
      });
      return;
    }
    changePasswordMutation.mutate(passwordData);
  };

  const handleSavePreferences = () => {
    savePreferencesMutation.mutate(preferences);
    
    // Apply theme change immediately
    if (preferences.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (preferences.theme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      // System theme
      const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', isDark);
    }
  };

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size
    if (file.size > 2 * 1024 * 1024) {
      toast({ 
        title: "❌ Arquivo muito grande", 
        description: "O arquivo deve ter no máximo 2MB.", 
        variant: "destructive" 
      });
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({ 
        title: "❌ Tipo inválido", 
        description: "Por favor, selecione uma imagem.", 
        variant: "destructive" 
      });
      return;
    }

    setUploadingAvatar(true);

    try {
      const formData = new FormData();
      formData.append('avatar', file);

      const response = await fetch('/api/upload/avatar', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });

      if (!response.ok) throw new Error('Upload failed');

      const data = await response.json();
      
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      
      toast({ 
        title: "✅ Foto atualizada!", 
        description: "Sua foto de perfil foi alterada com sucesso." 
      });
    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast({ 
        title: "❌ Erro no upload", 
        description: "Não foi possível fazer upload da foto.", 
        variant: "destructive" 
      });
    } finally {
      setUploadingAvatar(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const userInitial = currentUser?.user?.fullName?.charAt(0) || currentUser?.user?.username?.charAt(0) || "U";
  const avatarUrl = currentUser?.user?.avatar;

  return (
    <div className="p-4 md:p-6 space-y-6 animate-in fade-in duration-500">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleAvatarUpload}
      />

      <div className="bg-gradient-to-r from-primary/10 via-chart-2/10 to-primary/10 p-6 rounded-lg border border-primary/20">
        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
          Configurações
        </h1>
        <p className="text-muted-foreground mt-1">
          Gerencie suas preferências e informações pessoais
        </p>
      </div>

      <Tabs defaultValue="perfil" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 lg:w-auto bg-muted/50 p-1 rounded-lg">
          <TabsTrigger value="perfil" className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Perfil</span>
          </TabsTrigger>
          <TabsTrigger value="seguranca" className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Segurança</span>
          </TabsTrigger>
          <TabsTrigger value="notificacoes" className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Notificações</span>
          </TabsTrigger>
          <TabsTrigger value="aparencia" className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Palette className="h-4 w-4" />
            <span className="hidden sm:inline">Aparência</span>
          </TabsTrigger>
          <TabsTrigger value="regional" className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Globe className="h-4 w-4" />
            <span className="hidden sm:inline">Regional</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="perfil" className="space-y-6">
          <Card className="border-2 hover:border-primary/30 transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-chart-2/5">
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Informações Pessoais
              </CardTitle>
              <CardDescription>
                Atualize suas informações pessoais e foto de perfil
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="flex items-center gap-6 p-4 bg-muted/30 rounded-lg">
                <div className="relative">
                  <Avatar className="h-24 w-24 ring-4 ring-primary/20 cursor-pointer hover:ring-primary/40 transition-all" onClick={handleAvatarClick}>
                    <AvatarImage src={avatarUrl} alt="Avatar" />
                    <AvatarFallback className="text-2xl bg-gradient-to-br from-primary to-chart-2 text-primary-foreground">
                      {userInitial}
                    </AvatarFallback>
                  </Avatar>
                  {uploadingAvatar && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full">
                      <Loader2 className="h-6 w-6 animate-spin text-white" />
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="gap-2 hover:bg-primary hover:text-primary-foreground transition-colors"
                    onClick={handleAvatarClick}
                    disabled={uploadingAvatar}
                  >
                    <Camera className="h-4 w-4" />
                    {uploadingAvatar ? "Enviando..." : "Alterar Foto"}
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    JPG, PNG ou GIF. Máx. 2MB
                  </p>
                </div>
              </div>

              <Separator />

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="nome" className="text-sm font-semibold">Nome Completo</Label>
                  <Input 
                    id="nome" 
                    placeholder="Seu nome completo"
                    value={profileData.fullName}
                    onChange={(e) => setProfileData({...profileData, fullName: e.target.value})}
                    className="border-2 focus:border-primary"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="username" className="text-sm font-semibold">Nome de Usuário</Label>
                  <Input 
                    id="username" 
                    placeholder="usuario"
                    value={profileData.username}
                    onChange={(e) => setProfileData({...profileData, username: e.target.value})}
                    className="border-2 focus:border-primary"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="flex items-center gap-2 text-sm font-semibold">
                    <Mail className="h-4 w-4 text-primary" />
                    Email
                  </Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="seu@email.com"
                    value={profileData.email}
                    onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                    className="border-2 focus:border-primary"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefone" className="flex items-center gap-2 text-sm font-semibold">
                    <Phone className="h-4 w-4 text-primary" />
                    Telefone
                  </Label>
                  <Input 
                    id="telefone" 
                    placeholder="(00) 00000-0000"
                    value={profileData.phone}
                    onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                    className="border-2 focus:border-primary"
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="font-semibold flex items-center gap-2 text-lg">
                  <Building className="h-5 w-5 text-primary" />
                  Informações da Empresa
                </h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="empresa" className="text-sm font-semibold">Nome da Empresa</Label>
                    <Input 
                      id="empresa" 
                      placeholder="Sua empresa"
                      value={profileData.company}
                      onChange={(e) => setProfileData({...profileData, company: e.target.value})}
                      className="border-2 focus:border-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cnpj" className="text-sm font-semibold">CNPJ/CPF</Label>
                    <Input 
                      id="cnpj" 
                      placeholder="00.000.000/0000-00"
                      value={profileData.cnpj}
                      onChange={(e) => setProfileData({...profileData, cnpj: e.target.value})}
                      className="border-2 focus:border-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cargo" className="text-sm font-semibold">Cargo</Label>
                    <Input 
                      id="cargo" 
                      placeholder="Seu cargo"
                      value={profileData.position}
                      onChange={(e) => setProfileData({...profileData, position: e.target.value})}
                      className="border-2 focus:border-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="setor" className="text-sm font-semibold">Setor</Label>
                    <Select value={profileData.department} onValueChange={(value) => setProfileData({...profileData, department: value})}>
                      <SelectTrigger id="setor" className="border-2 focus:border-primary">
                        <SelectValue placeholder="Selecione o setor" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="financeiro">Financeiro</SelectItem>
                        <SelectItem value="comercial">Comercial</SelectItem>
                        <SelectItem value="administrativo">Administrativo</SelectItem>
                        <SelectItem value="ti">TI</SelectItem>
                        <SelectItem value="outro">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="font-semibold flex items-center gap-2 text-lg">
                  <MapPin className="h-5 w-5 text-primary" />
                  Endereço
                </h3>
                <div className="grid gap-4">
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="endereco" className="text-sm font-semibold">Endereço</Label>
                      <Input 
                        id="endereco" 
                        placeholder="Rua, Avenida, etc."
                        value={profileData.address}
                        onChange={(e) => setProfileData({...profileData, address: e.target.value})}
                        className="border-2 focus:border-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="numero" className="text-sm font-semibold">Número</Label>
                      <Input 
                        id="numero" 
                        placeholder="123"
                        value={profileData.addressNumber}
                        onChange={(e) => setProfileData({...profileData, addressNumber: e.target.value})}
                        className="border-2 focus:border-primary"
                      />
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <Label htmlFor="complemento" className="text-sm font-semibold">Complemento</Label>
                      <Input 
                        id="complemento" 
                        placeholder="Apto, Sala, etc."
                        value={profileData.complement}
                        onChange={(e) => setProfileData({...profileData, complement: e.target.value})}
                        className="border-2 focus:border-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bairro" className="text-sm font-semibold">Bairro</Label>
                      <Input 
                        id="bairro" 
                        placeholder="Seu bairro"
                        value={profileData.neighborhood}
                        onChange={(e) => setProfileData({...profileData, neighborhood: e.target.value})}
                        className="border-2 focus:border-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cep" className="text-sm font-semibold">CEP</Label>
                      <Input 
                        id="cep" 
                        placeholder="00000-000"
                        value={profileData.zipCode}
                        onChange={(e) => setProfileData({...profileData, zipCode: e.target.value})}
                        className="border-2 focus:border-primary"
                      />
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="cidade" className="text-sm font-semibold">Cidade</Label>
                      <Input 
                        id="cidade" 
                        placeholder="Sua cidade"
                        value={profileData.city}
                        onChange={(e) => setProfileData({...profileData, city: e.target.value})}
                        className="border-2 focus:border-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="estado" className="text-sm font-semibold">Estado</Label>
                      <Select value={profileData.state} onValueChange={(value) => setProfileData({...profileData, state: value})}>
                        <SelectTrigger id="estado" className="border-2 focus:border-primary">
                          <SelectValue placeholder="Selecione o estado" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="SP">São Paulo</SelectItem>
                          <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                          <SelectItem value="MG">Minas Gerais</SelectItem>
                          <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                          <SelectItem value="PR">Paraná</SelectItem>
                          <SelectItem value="SC">Santa Catarina</SelectItem>
                          <SelectItem value="BA">Bahia</SelectItem>
                          <SelectItem value="PE">Pernambuco</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="bio" className="text-sm font-semibold">Sobre</Label>
                <Textarea
                  id="bio"
                  placeholder="Conte um pouco sobre você ou sua empresa..."
                  className="resize-none border-2 focus:border-primary min-h-[100px]"
                  value={profileData.bio}
                  onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
                />
              </div>

              <Button 
                onClick={handleSaveProfile} 
                className="w-full gap-2 bg-gradient-to-r from-primary to-chart-2 hover:opacity-90 transition-opacity"
                disabled={updateProfileMutation.isPending}
              >
                {updateProfileMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Salvar Alterações
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seguranca" className="space-y-6">
          <Card className="border-2 hover:border-primary/30 transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-chart-2/5">
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Alterar Senha
              </CardTitle>
              <CardDescription>
                Mantenha sua conta segura com uma senha forte
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="space-y-2">
                <Label htmlFor="senha-atual" className="text-sm font-semibold">Senha Atual</Label>
                <div className="relative">
                  <Input
                    id="senha-atual"
                    type={showPassword ? "text" : "password"}
                    placeholder="Digite sua senha atual"
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                    className="border-2 focus:border-primary pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="nova-senha" className="text-sm font-semibold">Nova Senha</Label>
                <div className="relative">
                  <Input
                    id="nova-senha"
                    type={showNewPassword ? "text" : "password"}
                    placeholder="Digite sua nova senha"
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                    className="border-2 focus:border-primary pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                  >
                    {showNewPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmar-senha" className="text-sm font-semibold">Confirmar Nova Senha</Label>
                <div className="relative">
                  <Input
                    id="confirmar-senha"
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="Confirme sua nova senha"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                    className="border-2 focus:border-primary pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <Button 
                onClick={handleChangePassword}
                className="w-full gap-2 bg-gradient-to-r from-primary to-chart-2 hover:opacity-90"
                disabled={changePasswordMutation.isPending}
              >
                {changePasswordMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Atualizando...
                  </>
                ) : (
                  <>
                    <Lock className="h-4 w-4" />
                    Atualizar Senha
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary/30 transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-chart-2/5">
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Autenticação de Dois Fatores
              </CardTitle>
              <CardDescription>
                Adicione uma camada extra de segurança à sua conta
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Autenticação de Dois Fatores (2FA)</Label>
                  <p className="text-sm text-muted-foreground">
                    Use um aplicativo autenticador para gerar códigos
                  </p>
                </div>
                <Switch 
                  checked={preferences.twoFactorEnabled}
                  onCheckedChange={(checked) => setPreferences({...preferences, twoFactorEnabled: checked})}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">SMS de Segurança</Label>
                  <p className="text-sm text-muted-foreground">
                    Receba códigos por SMS em seu telefone
                  </p>
                </div>
                <Switch 
                  checked={preferences.smsSecurityEnabled}
                  onCheckedChange={(checked) => setPreferences({...preferences, smsSecurityEnabled: checked})}
                />
              </div>
              <Button 
                onClick={handleSavePreferences}
                className="w-full gap-2 bg-gradient-to-r from-primary to-chart-2 hover:opacity-90"
                disabled={savePreferencesMutation.isPending}
              >
                {savePreferencesMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Salvar Configurações
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 border-destructive/50 hover:border-destructive transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-destructive/5 to-destructive/10">
              <CardTitle className="text-destructive flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Zona de Perigo
              </CardTitle>
              <CardDescription>
                Ações irreversíveis relacionadas à sua conta
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Desativar Conta</Label>
                  <p className="text-sm text-muted-foreground">
                    Desative temporariamente sua conta
                  </p>
                </div>
                <Button variant="outline" size="sm" className="hover:bg-destructive/10 hover:text-destructive hover:border-destructive">
                  Desativar
                </Button>
              </div>
              <Separator />
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Excluir Conta</Label>
                  <p className="text-sm text-muted-foreground">
                    Exclua permanentemente sua conta e todos os dados
                  </p>
                </div>
                <Button variant="destructive" size="sm">
                  Excluir Conta
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notificacoes" className="space-y-6">
          <Card className="border-2 hover:border-primary/30 transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-chart-2/5">
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                Notificações por Email
              </CardTitle>
              <CardDescription>
                Configure quais notificações você deseja receber por email
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Relatórios Financeiros</Label>
                  <p className="text-sm text-muted-foreground">
                    Receba resumos diários das suas finanças
                  </p>
                </div>
                <Switch 
                  checked={preferences.emailFinancialReports}
                  onCheckedChange={(checked) => setPreferences({...preferences, emailFinancialReports: checked})}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Contas a Vencer</Label>
                  <p className="text-sm text-muted-foreground">
                    Alertas sobre contas próximas do vencimento
                  </p>
                </div>
                <Switch 
                  checked={preferences.emailBillsDue}
                  onCheckedChange={(checked) => setPreferences({...preferences, emailBillsDue: checked})}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Novidades e Atualizações</Label>
                  <p className="text-sm text-muted-foreground">
                    Fique por dentro das novidades do sistema
                  </p>
                </div>
                <Switch 
                  checked={preferences.emailUpdates}
                  onCheckedChange={(checked) => setPreferences({...preferences, emailUpdates: checked})}
                />
              </div>
              <Button 
                onClick={handleSavePreferences}
                className="w-full gap-2 bg-gradient-to-r from-primary to-chart-2 hover:opacity-90"
                disabled={savePreferencesMutation.isPending}
              >
                {savePreferencesMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Salvar Preferências
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary/30 transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-chart-2/5">
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Notificações Push
              </CardTitle>
              <CardDescription>
                Notificações no navegador e aplicativo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Transações Importantes</Label>
                  <p className="text-sm text-muted-foreground">
                    Notificações sobre movimentações financeiras
                  </p>
                </div>
                <Switch 
                  checked={preferences.pushTransactions}
                  onCheckedChange={(checked) => setPreferences({...preferences, pushTransactions: checked})}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Alertas de Segurança</Label>
                  <p className="text-sm text-muted-foreground">
                    Notificações sobre atividades suspeitas
                  </p>
                </div>
                <Switch 
                  checked={preferences.pushSecurity}
                  onCheckedChange={(checked) => setPreferences({...preferences, pushSecurity: checked})}
                />
              </div>
              <Button 
                onClick={handleSavePreferences}
                className="w-full gap-2 bg-gradient-to-r from-primary to-chart-2 hover:opacity-90"
                disabled={savePreferencesMutation.isPending}
              >
                {savePreferencesMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Salvar Preferências
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="aparencia" className="space-y-6">
          <Card className="border-2 hover:border-primary/30 transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-chart-2/5">
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-primary" />
                Tema
              </CardTitle>
              <CardDescription>
                Personalize a aparência do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Modo de Exibição</Label>
                <Select value={preferences.theme} onValueChange={(value) => setPreferences({...preferences, theme: value})}>
                  <SelectTrigger className="border-2 focus:border-primary">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Claro</SelectItem>
                    <SelectItem value="dark">Escuro</SelectItem>
                    <SelectItem value="system">Sistema</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Separator />
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Cor de Destaque</Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Escolha a cor principal do sistema
                </p>
                <div className="flex gap-3 flex-wrap">
                  {[
                    { name: 'violet', color: 'bg-violet-500', ring: 'ring-violet-500' },
                    { name: 'blue', color: 'bg-blue-500', ring: 'ring-blue-500' },
                    { name: 'green', color: 'bg-green-500', ring: 'ring-green-500' },
                    { name: 'orange', color: 'bg-orange-500', ring: 'ring-orange-500' },
                    { name: 'pink', color: 'bg-pink-500', ring: 'ring-pink-500' },
                    { name: 'cyan', color: 'bg-cyan-500', ring: 'ring-cyan-500' },
                  ].map((colorOption) => (
                    <button
                      key={colorOption.name}
                      className={`w-14 h-14 rounded-lg ${colorOption.color} cursor-pointer hover:scale-110 transition-transform relative ${
                        preferences.accentColor === colorOption.name ? `ring-4 ${colorOption.ring} shadow-lg` : ''
                      }`}
                      onClick={() => setPreferences({...preferences, accentColor: colorOption.name})}
                      type="button"
                    >
                      {preferences.accentColor === colorOption.name && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Check className="h-6 w-6 text-white drop-shadow-lg" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
              <Button 
                onClick={handleSavePreferences}
                className="w-full gap-2 bg-gradient-to-r from-primary to-chart-2 hover:opacity-90"
                disabled={savePreferencesMutation.isPending}
              >
                {savePreferencesMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Salvar Aparência
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary/30 transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-chart-2/5">
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-primary" />
                Interface
              </CardTitle>
              <CardDescription>
                Ajustes de visualização e acessibilidade
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Modo Compacto</Label>
                  <p className="text-sm text-muted-foreground">
                    Reduza o espaçamento entre elementos
                  </p>
                </div>
                <Switch 
                  checked={preferences.compactMode}
                  onCheckedChange={(checked) => setPreferences({...preferences, compactMode: checked})}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="space-y-0.5">
                  <Label className="text-sm font-semibold">Animações</Label>
                  <p className="text-sm text-muted-foreground">
                    Ative animações e transições suaves
                  </p>
                </div>
                <Switch 
                  checked={preferences.animations}
                  onCheckedChange={(checked) => setPreferences({...preferences, animations: checked})}
                />
              </div>
              <Separator />
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Tamanho da Fonte</Label>
                <Select value={preferences.fontSize} onValueChange={(value) => setPreferences({...preferences, fontSize: value})}>
                  <SelectTrigger className="border-2 focus:border-primary">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Pequena</SelectItem>
                    <SelectItem value="medium">Média</SelectItem>
                    <SelectItem value="large">Grande</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleSavePreferences}
                className="w-full gap-2 bg-gradient-to-r from-primary to-chart-2 hover:opacity-90"
                disabled={savePreferencesMutation.isPending}
              >
                {savePreferencesMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Salvar Interface
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="regional" className="space-y-6">
          <Card className="border-2 hover:border-primary/30 transition-all duration-300 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-chart-2/5">
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-primary" />
                Idioma e Região
              </CardTitle>
              <CardDescription>
                Configure o idioma e fuso horário
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="space-y-2">
                <Label htmlFor="idioma" className="text-sm font-semibold">Idioma do Sistema</Label>
                <Select value={preferences.language} onValueChange={(value) => setPreferences({...preferences, language: value})}>
                  <SelectTrigger id="idioma" className="border-2 focus:border-primary">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pt-br">Português (Brasil)</SelectItem>
                    <SelectItem value="en">English (US)</SelectItem>
                    <SelectItem value="es">Español</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Separator />
              <div className="space-y-2">
                <Label htmlFor="timezone" className="text-sm font-semibold">Fuso Horário</Label>
                <Select value={preferences.timezone} onValueChange={(value) => setPreferences({...preferences, timezone: value})}>
                  <SelectTrigger id="timezone" className="border-2 focus:border-primary">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="America/Sao_Paulo">América/São Paulo (GMT-3)</SelectItem>
                    <SelectItem value="America/New_York">América/Nova York (GMT-5)</SelectItem>
                    <SelectItem value="Europe/London">Europa/Londres (GMT+0)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleSavePreferences}
                className="w-full gap-2 bg-gradient-to-r from-primary to-chart-2 hover:opacity-90"
                disabled={savePreferencesMutation.isPending}
              >
                {savePreferencesMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Salvar Configurações Regionais
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
