import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState({
    email: "",
    password: "",
  });

  const validateEmail = (email: string) => {
    if (!email) return "E-mail é obrigatório";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return "E-mail inválido";
    return "";
  };

  const validatePassword = (password: string) => {
    if (!password) return "Senha é obrigatória";
    if (password.length < 6) return "Senha deve ter no mínimo 6 caracteres";
    return "";
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
    if (field === "email") {
      setErrors({ ...errors, email: "" });
    } else if (field === "password") {
      setErrors({ ...errors, password: "" });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const emailError = validateEmail(formData.email);
    const passwordError = validatePassword(formData.password);

    if (emailError || passwordError) {
      setErrors({
        email: emailError,
        password: passwordError,
      });
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: formData.email,
          password: formData.password,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Login realizado com sucesso!",
          description: "Redirecionando para o dashboard...",
        });
        setTimeout(() => {
          setLocation("/dashboard");
        }, 500);
      } else {
        toast({
          title: "Erro ao fazer login",
          description: data.message || "Verifique suas credenciais e tente novamente.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro de conexão",
        description: "Não foi possível conectar ao servidor.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-violet-50 via-white to-purple-50">
      <div className="flex-1 flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
        <div className="w-full max-w-[400px] space-y-6">
          <div className="text-center">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-violet-600 to-purple-600 shadow-lg shadow-violet-500/30 mb-4">
                <svg
                  className="w-10 h-10 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <h1 className="text-2xl font-bold text-violet-600 mb-1">Lucrei</h1>
              <p className="text-sm text-gray-500">Sistema de Gestão Financeira</p>
            </div>
            
            <h2 className="text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">
              Acesse sua conta
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              ou{" "}
              <button
                type="button"
                onClick={() => setLocation("/registro")}
                className="font-medium text-violet-600 hover:text-violet-700 transition-colors"
              >
                Crie sua conta grátis
              </button>
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div className="space-y-5">
              <div>
                <Label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  E-mail
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="Informe seu e-mail"
                  className="h-12 px-4 text-base border-gray-300 focus:border-violet-500 focus:ring-violet-500"
                  aria-label="Campo de e-mail"
                  aria-invalid={!!errors.email}
                  aria-describedby={errors.email ? "email-error" : undefined}
                />
                {errors.email && (
                  <p id="email-error" className="mt-2 text-sm text-red-600" role="alert">
                    {errors.email}
                  </p>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label htmlFor="password" className="block text-sm font-medium text-gray-700">
                    Senha
                  </Label>
                  <button
                    type="button"
                    onClick={() => setLocation("/recuperar-senha")}
                    className="text-sm font-medium text-violet-600 hover:text-violet-700 transition-colors"
                  >
                    Esqueceu sua senha?
                  </button>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    value={formData.password}
                    onChange={(e) => handleInputChange("password", e.target.value)}
                    placeholder="Informe sua senha"
                    className="h-12 px-4 pr-12 text-base border-gray-300 focus:border-violet-500 focus:ring-violet-500"
                    aria-label="Campo de senha"
                    aria-invalid={!!errors.password}
                    aria-describedby={errors.password ? "password-error" : undefined}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
                    aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" aria-hidden="true" />
                    ) : (
                      <Eye className="w-5 h-5" aria-hidden="true" />
                    )}
                  </button>
                </div>
                {errors.password && (
                  <p id="password-error" className="mt-2 text-sm text-red-600" role="alert">
                    {errors.password}
                  </p>
                )}
              </div>
            </div>

            <div>
              <Button
                type="submit"
                disabled={loading}
                className="w-full h-12 bg-violet-600 hover:bg-violet-700 text-white text-base font-medium rounded-lg transition-colors focus:ring-2 focus:ring-offset-2 focus:ring-violet-600 shadow-md"
                aria-label="Botão de entrar"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" aria-hidden="true" />
                    Entrando...
                  </>
                ) : (
                  "Entrar"
                )}
              </Button>
            </div>

            <div className="text-center">
              <p className="text-sm text-gray-600">
                Não recebeu instruções de confirmação?{" "}
                <button
                  type="button"
                  onClick={() => setLocation("/reenviar-confirmacao")}
                  className="font-medium text-violet-600 hover:text-violet-700 transition-colors"
                >
                  Reenviar
                </button>
              </p>
            </div>
          </form>
        </div>
      </div>

      <footer className="bg-white/80 backdrop-blur-sm border-t border-violet-100 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center">
              <svg
                className="w-8 h-8 text-violet-600"
                fill="currentColor"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
              </svg>
            </div>
            
            <p className="text-sm text-gray-600">
              ©2025 Lucrei Tecnologia. Todos os direitos reservados.
            </p>
            
            <div className="flex items-center justify-center space-x-6">
              <button
                type="button"
                onClick={() => setLocation("/sobre")}
                className="text-sm text-violet-600 hover:text-violet-700 transition-colors"
              >
                Sobre
              </button>
              <span className="text-violet-200">•</span>
              <button
                type="button"
                onClick={() => setLocation("/termos")}
                className="text-sm text-violet-600 hover:text-violet-700 transition-colors"
              >
                Termos de uso
              </button>
              <span className="text-violet-200">•</span>
              <button
                type="button"
                onClick={() => setLocation("/privacidade")}
                className="text-sm text-violet-600 hover:text-violet-700 transition-colors"
              >
                Privacidade
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
