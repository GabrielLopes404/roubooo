import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Loader2, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function RecuperarSenha() {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const validateEmail = (email: string) => {
    if (!email) return "E-mail é obrigatório";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return "E-mail inválido";
    return "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const emailError = validateEmail(email);
    if (emailError) {
      setError(emailError);
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess(true);
        toast({
          title: "E-mail enviado!",
          description: "Verifique sua caixa de entrada para redefinir sua senha.",
        });
      } else {
        toast({
          title: "Erro ao enviar e-mail",
          description: data.message || "Não foi possível processar sua solicitação.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro de conexão",
        description: "Não foi possível conectar ao servidor.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex flex-col bg-white">
        <div className="flex-1 flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
          <div className="w-full max-w-md space-y-8">
            <div className="text-center">
              <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-6">
                <Mail className="h-8 w-8 text-green-600" aria-hidden="true" />
              </div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                E-mail enviado!
              </h2>
              <p className="mt-4 text-base text-gray-600">
                Enviamos instruções para redefinir sua senha para <strong>{email}</strong>.
                Verifique sua caixa de entrada e siga as instruções.
              </p>
              <div className="mt-8">
                <Button
                  type="button"
                  onClick={() => setLocation("/login")}
                  className="w-full h-12 bg-[#635BFF] hover:bg-[#5147E5] text-white text-base font-medium rounded-lg"
                >
                  Voltar para o login
                </Button>
              </div>
            </div>
          </div>
        </div>

        <footer className="bg-gray-50 border-t border-gray-200 py-8 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="text-center space-y-4">
              <p className="text-sm text-gray-600">
                ©2025 Lucrei Tecnologia. Todos os direitos reservados.
              </p>
              
              <div className="flex items-center justify-center space-x-6">
                <button
                  type="button"
                  onClick={() => setLocation("/sobre")}
                  className="text-sm text-[#635BFF] hover:text-[#5147E5] transition-colors"
                >
                  Sobre
                </button>
                <span className="text-gray-300">•</span>
                <button
                  type="button"
                  onClick={() => setLocation("/termos")}
                  className="text-sm text-[#635BFF] hover:text-[#5147E5] transition-colors"
                >
                  Termos de uso
                </button>
                <span className="text-gray-300">•</span>
                <button
                  type="button"
                  onClick={() => setLocation("/privacidade")}
                  className="text-sm text-[#635BFF] hover:text-[#5147E5] transition-colors"
                >
                  Privacidade
                </button>
              </div>
            </div>
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-violet-50 via-white to-purple-50">
      <div className="flex-1 flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
        <div className="w-full max-w-[400px] space-y-6">
          <div>
            <button
              type="button"
              onClick={() => setLocation("/login")}
              className="inline-flex items-center text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors mb-8"
              aria-label="Voltar para o login"
            >
              <ArrowLeft className="mr-2 h-4 w-4" aria-hidden="true" />
              Voltar para o login
            </button>
            
            <div className="text-center">
              <div className="mb-6">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-violet-600 to-purple-600 shadow-lg shadow-violet-500/30 mb-4">
                  <svg
                    className="w-10 h-10 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h1 className="text-2xl font-bold text-violet-600 mb-1">Lucrei</h1>
                <p className="text-sm text-gray-500">Sistema de Gestão Financeira</p>
              </div>
              
              <h2 className="text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">
                Recuperar senha
              </h2>
              <p className="mt-2 text-sm text-gray-600">
                Digite seu e-mail para receber instruções de recuperação
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div>
              <Label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                E-mail
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setError("");
                }}
                placeholder="Informe seu e-mail"
                className="h-12 px-4 text-base border-gray-300 focus:border-violet-500 focus:ring-violet-500"
                aria-label="Campo de e-mail"
                aria-invalid={!!error}
                aria-describedby={error ? "email-error" : undefined}
              />
              {error && (
                <p id="email-error" className="mt-2 text-sm text-red-600" role="alert">
                  {error}
                </p>
              )}
            </div>

            <div>
              <Button
                type="submit"
                disabled={loading}
                className="w-full h-12 bg-violet-600 hover:bg-violet-700 text-white text-base font-medium rounded-lg transition-colors focus:ring-2 focus:ring-offset-2 focus:ring-violet-600 shadow-md"
                aria-label="Enviar instruções de recuperação"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" aria-hidden="true" />
                    Enviando...
                  </>
                ) : (
                  "Enviar instruções"
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>

      <footer className="bg-white/80 backdrop-blur-sm border-t border-violet-100 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center">
              <svg
                className="w-8 h-8 text-violet-600"
                fill="currentColor"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
              </svg>
            </div>
            
            <p className="text-sm text-gray-600">
              ©2025 Lucrei Tecnologia. Todos os direitos reservados.
            </p>
            
            <div className="flex items-center justify-center space-x-6">
              <button
                type="button"
                onClick={() => setLocation("/sobre")}
                className="text-sm text-violet-600 hover:text-violet-700 transition-colors"
              >
                Sobre
              </button>
              <span className="text-violet-200">•</span>
              <button
                type="button"
                onClick={() => setLocation("/termos")}
                className="text-sm text-violet-600 hover:text-violet-700 transition-colors"
              >
                Termos de uso
              </button>
              <span className="text-violet-200">•</span>
              <button
                type="button"
                onClick={() => setLocation("/privacidade")}
                className="text-sm text-violet-600 hover:text-violet-700 transition-colors"
              >
                Privacidade
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
