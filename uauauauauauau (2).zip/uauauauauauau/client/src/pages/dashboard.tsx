import { motion } from "framer-motion";
import { MetricCard } from "@/components/metric-card";
import { ProgressRing } from "@/components/progress-ring";
import { CalendarWidget } from "@/components/calendar-widget";
import { EmptyState } from "@/components/empty-state";
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Clock,
  Plus,
  Upload,
  FileText,
  Info,
  Wallet,
  ArrowRight,
  Zap,
  BarChart,
  Activity
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LineChart,
  Line,
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";

const cashFlowData = [
  { month: "Jan", receitas: 45000, despesas: 32000, saldo: 13000 },
  { month: "Fev", receitas: 52000, despesas: 38000, saldo: 14000 },
  { month: "Mar", receitas: 48000, despesas: 35000, saldo: 13000 },
  { month: "Abr", receitas: 61000, despesas: 42000, saldo: 19000 },
  { month: "Mai", receitas: 55000, despesas: 39000, saldo: 16000 },
  { month: "Jun", receitas: 67000, despesas: 45000, saldo: 22000 },
];

const recentTransactions = [
  { id: 1, description: "Pagamento Cliente ABC", value: 5200, type: "receita", date: "2024-11-01" },
  { id: 2, description: "Fornecedor XYZ Ltda", value: -2800, type: "despesa", date: "2024-11-01" },
  { id: 3, description: "Serviço Consultoria", value: 3500, type: "receita", date: "2024-10-31" },
  { id: 4, description: "Aluguel Escritório", value: -4200, type: "despesa", date: "2024-10-30" },
  { id: 5, description: "Venda Produto Premium", value: 8900, type: "receita", date: "2024-10-30" },
];

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 }
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900/95 border border-white/20 rounded-lg p-3 shadow-xl backdrop-blur-sm">
        <p className="text-sm font-medium text-white mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-xs text-slate-300" style={{ color: entry.color }}>
            {entry.name}: R$ {entry.value.toLocaleString('pt-BR')}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Dashboard() {
  return (
    <div className="flex-1 w-full max-w-full overflow-x-hidden space-y-4 sm:space-y-6 p-3 sm:p-4 md:p-6 bg-gradient-to-br from-background via-background to-primary/5">
      {/* Header */}
      <motion.div 
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent animate-gradient">
            Bom dia, Gabriel.
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base md:text-lg">Visão geral das suas finanças em tempo real</p>
        </div>
        <div className="flex gap-2 sm:gap-3 w-full sm:w-auto">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex-1 sm:flex-initial">
            <Button variant="outline" data-testid="button-import-ofx" className="w-full sm:w-auto border-2 hover:border-primary/50 hover:bg-primary/5 text-xs sm:text-sm h-9 sm:h-10">
              <Upload className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
              <span className="hidden xs:inline">Importar OFX</span>
              <span className="xs:hidden">Importar</span>
            </Button>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05, y: -2 }} whileTap={{ scale: 0.95 }} className="flex-1 sm:flex-initial">
            <Button data-testid="button-new-transaction" className="w-full sm:w-auto bg-gradient-to-r from-primary via-chart-2 to-chart-4 animate-gradient shadow-lg hover:shadow-xl hover:shadow-primary/50 text-xs sm:text-sm h-9 sm:h-10">
              <Plus className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
              <span className="hidden xs:inline">Nova Transação</span>
              <span className="xs:hidden">Nova</span>
            </Button>
          </motion.div>
        </div>
      </motion.div>

      <div className="grid gap-4 sm:gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4 sm:space-y-6">
          {/* Previsto/Realizado no Mês */}
          <motion.div {...fadeInUp}>
            <Card className="border-2 border-primary/20 hover:border-primary/40 transition-all shadow-lg hover:shadow-xl hover:shadow-primary/10 backdrop-blur-sm bg-card/95 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-primary/5 via-chart-2/5 to-transparent p-3 sm:p-4 md:p-6">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 sm:gap-0">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg md:text-xl">
                    <div className="p-1.5 sm:p-2 bg-gradient-to-br from-primary to-chart-2 rounded-lg">
                      <Zap className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                    </div>
                    Previsto / realizado no mês
                  </CardTitle>
                  <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                    <Badge variant="outline" className="font-mono bg-primary/10 border-primary/30 text-xs">NOV/2025</Badge>
                    <span className="font-medium hidden sm:inline">Conta Principal</span>
                    <Info className="h-3 w-3 sm:h-4 sm:w-4 cursor-help hover:text-primary transition-colors" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 md:p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
                  <motion.div 
                    className="space-y-3 sm:space-y-4"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <div className="flex justify-center">
                      <ProgressRing
                        progress={100}
                        size={window.innerWidth < 640 ? 100 : 120}
                        strokeWidth={window.innerWidth < 640 ? 7 : 8}
                        color="hsl(var(--chart-2))"
                        label="Recebido"
                      />
                    </div>
                    <div className="space-y-1 sm:space-y-2">
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-success/5 transition-colors">
                        <span className="text-xs sm:text-sm font-medium text-muted-foreground">Recebido</span>
                        <span className="font-bold font-mono text-base sm:text-lg text-success">R$ 80,00</span>
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <span className="text-xs sm:text-sm font-medium text-muted-foreground">Falta</span>
                        <span className="font-bold font-mono text-base sm:text-lg">R$ 0,00</span>
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <span className="text-xs sm:text-sm font-medium text-muted-foreground">Previsto</span>
                        <span className="font-bold font-mono text-base sm:text-lg">R$ 80,00</span>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div 
                    className="space-y-3 sm:space-y-4"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    <div className="flex justify-center">
                      <ProgressRing
                        progress={100}
                        size={window.innerWidth < 640 ? 100 : 120}
                        strokeWidth={window.innerWidth < 640 ? 7 : 8}
                        color="hsl(var(--destructive))"
                        label="Pago"
                      />
                    </div>
                    <div className="space-y-1 sm:space-y-2">
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-destructive/5 transition-colors">
                        <span className="text-xs sm:text-sm font-medium text-muted-foreground">Pago</span>
                        <span className="font-bold font-mono text-base sm:text-lg text-destructive">R$ 80,00</span>
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <span className="text-xs sm:text-sm font-medium text-muted-foreground">Falta</span>
                        <span className="font-bold font-mono text-base sm:text-lg">R$ 0,00</span>
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <span className="text-xs sm:text-sm font-medium text-muted-foreground">Previsto</span>
                        <span className="font-bold font-mono text-base sm:text-lg">R$ 80,00</span>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Fluxo de Caixa - Gráfico de Área Melhorado */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="border-2 hover:border-primary/30 transition-colors overflow-hidden">
              <CardHeader className="p-3 sm:p-4 md:p-6">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <div className="p-1.5 sm:p-2 bg-gradient-to-br from-success to-emerald-600 rounded-lg">
                      <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                    </div>
                    Fluxo de caixa
                  </CardTitle>
                  <div className="text-xs sm:text-sm text-muted-foreground flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-xs">JAN-JUN/2025</Badge>
                    <span className="hidden sm:inline">Conta Principal</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 md:p-6 pt-0">
                <div className="mb-3 sm:mb-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl sm:text-2xl md:text-3xl font-bold font-mono bg-gradient-to-r from-success to-emerald-600 bg-clip-text text-transparent">
                      R$ 97.000
                    </span>
                    <div className="flex items-center gap-1 text-success text-xs sm:text-sm">
                      <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4" />
                      <span className="font-semibold">+23%</span>
                    </div>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground mt-1">Saldo acumulado do período</p>
                </div>
                <ResponsiveContainer width="100%" height={window.innerWidth < 640 ? 180 : window.innerWidth < 1024 ? 220 : 260}>
                  <AreaChart data={cashFlowData}>
                    <defs>
                      <linearGradient id="colorReceitas" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorDespesas" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted/30" />
                    <XAxis 
                      dataKey="month" 
                      className="text-xs" 
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: window.innerWidth < 640 ? 10 : 12 }}
                    />
                    <YAxis 
                      className="text-xs" 
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: window.innerWidth < 640 ? 10 : 12 }}
                      tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Area 
                      type="monotone" 
                      dataKey="receitas" 
                      stroke="hsl(var(--chart-2))" 
                      strokeWidth={3}
                      fill="url(#colorReceitas)"
                      name="Receitas"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="despesas" 
                      stroke="hsl(var(--destructive))" 
                      strokeWidth={3}
                      fill="url(#colorDespesas)"
                      name="Despesas"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          {/* Comparativo Melhorado */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="border-2 hover:border-primary/30 transition-colors overflow-hidden">
              <CardHeader className="p-3 sm:p-4 md:p-6">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <div className="p-1.5 sm:p-2 bg-gradient-to-br from-primary to-chart-4 rounded-lg">
                      <BarChart className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                    </div>
                    Comparativo
                  </CardTitle>
                  <div className="text-xs sm:text-sm text-muted-foreground flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-xs">NOV/2025</Badge>
                    <span className="hidden sm:inline">vs. mês anterior</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 md:p-6 pt-0">
                <div className="space-y-4 sm:space-y-6">
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 sm:w-3 sm:h-3 rounded-full bg-success" />
                        <span className="text-xs sm:text-sm font-medium">Recebimentos</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-muted-foreground">R$ 67.000</span>
                        <div className="flex items-center gap-0.5 text-success text-xs">
                          <TrendingUp className="h-3 w-3" />
                          <span className="font-semibold">+15%</span>
                        </div>
                      </div>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2 sm:h-3 overflow-hidden">
                      <motion.div 
                        className="bg-gradient-to-r from-success to-emerald-500 h-2 sm:h-3 rounded-full shadow-lg shadow-success/50"
                        initial={{ width: 0 }}
                        animate={{ width: '75%' }}
                        transition={{ duration: 1, delay: 0.6 }}
                      />
                    </div>
                  </motion.div>

                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 sm:w-3 sm:h-3 rounded-full bg-destructive" />
                        <span className="text-xs sm:text-sm font-medium">Despesas</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-muted-foreground">R$ 45.000</span>
                        <div className="flex items-center gap-0.5 text-destructive text-xs">
                          <TrendingUp className="h-3 w-3" />
                          <span className="font-semibold">+8%</span>
                        </div>
                      </div>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2 sm:h-3 overflow-hidden">
                      <motion.div 
                        className="bg-gradient-to-r from-destructive to-red-500 h-2 sm:h-3 rounded-full shadow-lg shadow-destructive/50"
                        initial={{ width: 0 }}
                        animate={{ width: '60%' }}
                        transition={{ duration: 1, delay: 0.7 }}
                      />
                    </div>
                  </motion.div>

                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 sm:w-3 sm:h-3 rounded-full bg-primary" />
                        <span className="text-xs sm:text-sm font-medium">Lucro Líquido</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-muted-foreground">R$ 22.000</span>
                        <div className="flex items-center gap-0.5 text-success text-xs">
                          <TrendingUp className="h-3 w-3" />
                          <span className="font-semibold">+27%</span>
                        </div>
                      </div>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2 sm:h-3 overflow-hidden">
                      <motion.div 
                        className="bg-gradient-to-r from-primary to-chart-4 h-2 sm:h-3 rounded-full shadow-lg shadow-primary/50"
                        initial={{ width: 0 }}
                        animate={{ width: '85%' }}
                        transition={{ duration: 1, delay: 0.8 }}
                      />
                    </div>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Últimas Atualizações */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="border-2 hover:border-primary/30 transition-colors overflow-hidden">
              <CardHeader className="p-3 sm:p-4 md:p-6">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <div className="p-1.5 sm:p-2 bg-gradient-to-br from-chart-4 to-purple-600 rounded-lg">
                      <Activity className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                    </div>
                    Últimas transações
                  </CardTitle>
                  <Button variant="ghost" size="sm" className="text-xs sm:text-sm">
                    Ver todas
                    <ArrowRight className="h-3 w-3 sm:h-4 sm:w-4 ml-1" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 md:p-6 pt-0">
                <div className="space-y-2 sm:space-y-3">
                  {recentTransactions.map((transaction) => (
                    <motion.div
                      key={transaction.id}
                      className="flex items-center justify-between p-2 sm:p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer group"
                      whileHover={{ x: 4 }}
                    >
                      <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                        <div className={`p-1.5 sm:p-2 rounded-lg ${transaction.type === 'receita' ? 'bg-success/20' : 'bg-destructive/20'}`}>
                          {transaction.type === 'receita' ? (
                            <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 text-success" />
                          ) : (
                            <TrendingDown className="h-3 w-3 sm:h-4 sm:w-4 text-destructive" />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs sm:text-sm font-medium truncate">{transaction.description}</p>
                          <p className="text-xs text-muted-foreground">{new Date(transaction.date).toLocaleDateString('pt-BR')}</p>
                        </div>
                      </div>
                      <div className={`text-xs sm:text-sm font-bold font-mono shrink-0 ${transaction.type === 'receita' ? 'text-success' : 'text-destructive'}`}>
                        {transaction.type === 'receita' ? '+' : ''}R$ {Math.abs(transaction.value).toLocaleString('pt-BR')}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4 sm:space-y-6">
          {/* Metrics Cards */}
          <motion.div
            variants={stagger}
            initial="initial"
            animate="animate"
            className="grid grid-cols-2 lg:grid-cols-1 gap-3 sm:gap-4 p-4"
          >
            <MetricCard
              title="Saldo Atual"
              value="R$ 97.240"
              change={{ value: "+23%", isPositive: true }}
              icon={Wallet}
              gradient="from-success to-emerald-600"
            />
            <MetricCard
              title="A Receber"
              value="R$ 12.450"
              change={{ value: "+12%", isPositive: true }}
              icon={TrendingUp}
              gradient="from-primary to-chart-2"
            />
            <MetricCard
              title="A Pagar"
              value="R$ 8.210"
              change={{ value: "-5%", isPositive: true }}
              icon={TrendingDown}
              gradient="from-destructive to-red-600"
            />
            <MetricCard
              title="Pendente"
              value="R$ 3.840"
              icon={Clock}
              gradient="from-chart-4 to-purple-600"
            />
          </motion.div>

          {/* Calendar Widget */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7 }}
          >
            <CalendarWidget />
          </motion.div>

          {/* Conta Principal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 }}
          >
            <Card className="border-2 hover:border-primary/30 transition-colors overflow-hidden">
              <CardHeader className="p-3 sm:p-4 md:p-6 bg-gradient-to-br from-primary/10 to-transparent">
                <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                  <div className="p-1.5 sm:p-2 bg-gradient-to-br from-primary to-chart-2 rounded-lg">
                    <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                  </div>
                  Conta Principal
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 md:p-6 pt-3 space-y-3 sm:space-y-4">
                <div>
                  <p className="text-xs sm:text-sm text-muted-foreground mb-1">Saldo atual</p>
                  <p className="text-xl sm:text-2xl md:text-3xl font-bold font-mono bg-gradient-to-r from-success to-emerald-600 bg-clip-text text-transparent">
                    R$ 35.689,42
                  </p>
                </div>
                <div className="pt-3 border-t border-border">
                  <p className="text-xs sm:text-sm text-muted-foreground mb-1">Previsão do mês</p>
                  <p className="text-base sm:text-lg md:text-xl font-bold font-mono text-foreground">
                    R$ 42.120,00
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
