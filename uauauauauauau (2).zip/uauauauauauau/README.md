# Lucrei - Sistema de Gestão Financeira

[![CI/CD](https://github.com/YOUR_USERNAME/YOUR_REPO/workflows/CI%2FCD%20Pipeline/badge.svg)](https://github.com/YOUR_USERNAME/YOUR_REPO/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 📋 Sobre o Projeto

**Lucrei** é uma plataforma completa de gestão financeira desenvolvida com as tecnologias mais modernas do mercado. O sistema oferece controle total sobre contas a pagar/receber, faturas, fluxo de caixa, conciliação bancária e muito mais.

### ✨ Principais Funcionalidades

- 📊 **Dashboard Interativo** - Visão geral completa das finanças em tempo real
- 💰 **Contas a Pagar/Receber** - Gestão completa de contas com recorrência
- 📄 **Faturas** - Emissão e controle de faturas
- 💵 **Fluxo de Caixa** - Acompanhamento detalhado de entradas e saídas
- 🔄 **Conciliação Bancária** - Importação e conciliação de extratos bancários (OFX, CSV)
- 👥 **Gestão de Contatos** - Cadastro de clientes e fornecedores
- 📈 **Relatórios** - Relatórios detalhados e exportação em PDF/Excel
- 🔔 **Notificações** - Sistema de notificações em tempo real via WebSocket
- 🎫 **Suporte** - Sistema de tickets para atendimento
- 📱 **Mobile-First** - Interface responsiva e otimizada para dispositivos móveis
- 🔒 **Segurança** - Autenticação JWT, criptografia, rate limiting, CSRF protection

## 🚀 Tecnologias

### Frontend
- **React 18** com TypeScript
- **Vite** - Build tool e dev server
- **Tailwind CSS** - Estilização
- **shadcn/ui** - Componentes UI
- **React Query** - Gerenciamento de estado assíncrono
- **Wouter** - Roteamento
- **Framer Motion** - Animações
- **Recharts** - Gráficos

### Backend
- **Node.js 20** com TypeScript
- **Express** - Framework web
- **PostgreSQL** (Neon) - Banco de dados
- **Drizzle ORM** - ORM type-safe
- **Passport.js** - Autenticação
- **JWT** - Tokens de acesso
- **WebSocket (ws)** - Comunicação em tempo real

### Segurança
- **Helmet** - Headers de segurança
- **CORS** - Controle de origem
- **Rate Limiting** - Proteção contra ataques
- **CSRF Protection** - Proteção contra CSRF
- **Bcrypt** - Hash de senhas
- **Crypto-JS** - Criptografia de dados sensíveis

## 📦 Instalação

### Pré-requisitos

- Node.js 20 ou superior
- PostgreSQL 14 ou superior
- npm ou yarn

### Passo a Passo

1. **Clone o repositório**
```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cd YOUR_REPO
```

2. **Instale as dependências**
```bash
npm install
```

3. **Configure as variáveis de ambiente**

Copie o arquivo `.env.example` para `.env` e preencha com suas credenciais:

```bash
cp .env.example .env
```

**Variáveis obrigatórias:**

```env
# Database
DATABASE_URL=postgres://user:password@localhost:5432/lucrei

# Security (generate with: openssl rand -base64 32)
ACCESS_TOKEN_SECRET=your-access-token-secret-min-32-chars
REFRESH_TOKEN_SECRET=your-refresh-token-secret-min-32-chars
SESSION_SECRET=your-session-secret-min-32-chars
ENCRYPTION_KEY=your-encryption-key-exactly-32-chars

# Application
NODE_ENV=development
PORT=5000
```

4. **Execute as migrações do banco de dados**
```bash
npm run db:migrate
npm run db:indices
```

5. **Inicie o servidor de desenvolvimento**
```bash
npm run dev
```

O servidor estará disponível em `http://localhost:5000`

### 👤 Credenciais Padrão

**Usuário admin:**
- Username: `admin`
- Password: `admin123`

⚠️ **Importante:** Altere a senha padrão após o primeiro login!

## 🛠️ Scripts Disponíveis

```bash
# Desenvolvimento
npm run dev          # Inicia servidor de desenvolvimento

# Build
npm run build        # Build de produção
npm run start        # Inicia servidor de produção

# Qualidade de Código
npm run lint         # Executa o linter
npm run lint:fix     # Corrige problemas de lint automaticamente
npm run format       # Formata o código com Prettier
npm run format:check # Verifica formatação
npm run check        # Type checking com TypeScript

# Testes
npm run test         # Executa todos os testes
npm run test:watch   # Executa testes em modo watch
npm run test:coverage# Gera relatório de cobertura

# Banco de Dados
npm run db:migrate   # Executa migrações
npm run db:push      # Sincroniza schema com o banco
npm run db:indices   # Cria índices de performance
```

## 🏗️ Estrutura do Projeto

```
.
├── client/                 # Frontend React
│   ├── public/            # Arquivos estáticos
│   └── src/
│       ├── components/    # Componentes React
│       │   ├── ui/       # Componentes UI base
│       │   └── ...       # Componentes específicos
│       ├── hooks/        # Custom React hooks
│       ├── lib/          # Utilitários
│       ├── pages/        # Páginas da aplicação
│       ├── styles/       # Estilos globais
│       └── test/         # Testes do frontend
├── server/                # Backend Node.js
│   ├── config/           # Configurações
│   ├── controllers/      # Controllers
│   ├── middlewares/      # Middlewares Express
│   ├── routes/           # Rotas da API
│   └── utils/            # Utilitários do servidor
├── shared/               # Código compartilhado
│   └── schema.ts        # Schema do banco de dados
├── uploads/             # Arquivos enviados pelos usuários
├── .github/             # GitHub Actions workflows
└── docs/                # Documentação adicional
```

## 🔐 Segurança

Este projeto implementa diversas camadas de segurança:

- ✅ Autenticação JWT com tokens de acesso e refresh
- ✅ Senhas com hash bcrypt (12 rounds)
- ✅ Criptografia AES-256 para dados sensíveis
- ✅ Proteção CSRF
- ✅ Rate limiting por IP
- ✅ Validação e sanitização de inputs
- ✅ Proteção contra SQL injection
- ✅ Headers de segurança com Helmet
- ✅ CORS configurado
- ✅ Logs de auditoria com hash chain

Veja [SECURITY.md](./SECURITY.md) para mais detalhes.

## 📱 Suporte a Dispositivos

- ✅ Desktop (1920x1080 e superiores)
- ✅ Laptop (1366x768)
- ✅ Tablet (768x1024)
- ✅ Mobile (375x667 e superiores)

## 🚀 Deploy

### Replit

O projeto está otimizado para deploy no Replit. Basta:

1. Importar o repositório no Replit
2. Configurar as variáveis de ambiente (Secrets)
3. Executar `npm install`
4. O servidor iniciará automaticamente

### Outros Provedores

O projeto inclui configurações para:
- **Railway** (`railway.json`)
- **Render** (`render.yaml`)
- **Google Cloud Platform** (`app.yaml`)
- **Docker** (`Dockerfile`)

## 🤝 Contribuindo

Contribuições são bem-vindas! Veja [CONTRIBUTING.md](./CONTRIBUTING.md) para detalhes sobre como contribuir.

## 📝 Licença

Este projeto está sob a licença MIT. Veja [LICENSE](./LICENSE) para mais informações.

## 👥 Autores

- **Equipe Lucrei** - Desenvolvimento e manutenção

## 📞 Suporte

- 📧 Email: support@lucrei.com
- 🐛 Issues: [GitHub Issues](https://github.com/YOUR_USERNAME/YOUR_REPO/issues)
- 📖 Documentação: [Wiki](https://github.com/YOUR_USERNAME/YOUR_REPO/wiki)

## 🗺️ Roadmap

- [ ] Integração com APIs bancárias (Open Banking)
- [ ] Relatórios avançados com BI
- [ ] App mobile nativo (React Native)
- [ ] Integração com emissão de NFe
- [ ] Dashboard de analytics avançado
- [ ] Integração com plataformas de pagamento (Stripe, PagSeguro)

---

Desenvolvido com ❤️ pela equipe Lucrei
